from pathlib import Path
from copy import deepcopy
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from zipfile import ZipFile
import hashlib

root=Path.cwd(); out=root/'outputs'
ref=Path(r'C:\Users\ADMIN\OneDrive\Desktop\Nguyen_VTIT\SRS_Chuc_nang_quan_ly_mo_cua_ngoai_gio.docx')
doc=Document(ref)
for e in list(doc.element.body):
 if e.tag!=qn('w:sectPr'): doc.element.body.remove(e)
for s in doc.sections:
 for p in s.header.paragraphs: p.text='ĐẶC TẢ YÊU CẦU CHỨC NĂNG NGHỈ PHÉP'
 for p in s.footer.paragraphs: p.text='SRS Quản lý yêu cầu nghỉ phép • Phiên bản 0.1'
for name in ['Title','Heading 1','Heading 2','Heading 3','Normal']:
 st=doc.styles[name]; st.font.color.rgb=RGBColor(0,0,0)
 st.paragraph_format.space_after=Pt(5)
doc.styles['Normal'].paragraph_format.line_spacing=1.05
def p(s=''): return doc.add_paragraph(s)
def h(s,level=1): return doc.add_paragraph(s,'Heading '+str(level))
def page(): doc.add_page_break()
def table(headers,rows,widths=None):
 if widths is None: widths=[6.75/len(headers)]*len(headers)
 t=doc.add_table(rows=1,cols=len(headers)); t.autofit=False
 for col,w in zip(t.columns,widths): col.width=Inches(w)
 for c,txt,w in zip(t.rows[0].cells,headers,widths): c.text=txt; c.width=Inches(w)
 for vals in rows:
  for c,txt,w in zip(t.add_row().cells,vals,widths): c.text=str(txt); c.width=Inches(w)
 for i,row in enumerate(t.rows):
  pr=row._tr.get_or_add_trPr(); pr.append(OxmlElement('w:cantSplit'))
  if i==0: pr.append(OxmlElement('w:tblHeader'))
  for c in row.cells:
   c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER; cp=c._tc.get_or_add_tcPr()
   bd=OxmlElement('w:tcBorders')
   for side in ['top','left','bottom','right']:
    e=OxmlElement('w:'+side); e.set(qn('w:val'),'single'); e.set(qn('w:sz'),'4'); e.set(qn('w:color'),'D9D9D9'); bd.append(e)
   cp.append(bd); mar=OxmlElement('w:tcMar')
   for side in ['top','left','bottom','right']:
    e=OxmlElement('w:'+side); e.set(qn('w:w'),'80'); e.set(qn('w:type'),'dxa'); mar.append(e)
   cp.append(mar)
   if i==0:
    sh=OxmlElement('w:shd'); sh.set(qn('w:fill'),'E8EEF5'); cp.append(sh)
   for pp in c.paragraphs:
    pp.paragraph_format.space_after=Pt(2); pp.paragraph_format.line_spacing=1.0
    for r in pp.runs: r.font.name='Arial'; r.font.size=Pt(10); r.font.bold=(i==0)
 p()
 return t
def pic(name,width=6.7):
 pp=p(); pp.alignment=WD_ALIGN_PARAGRAPH.CENTER
 pp.add_run().add_picture(str(out/name),width=Inches(width))

report=Document(out/'Báo cáo sơ bộ nghỉ phép Happy Connect.docx')
functions=[]
for i,row in enumerate(report.tables[0].rows[1:],1):
 c=[x.text for x in row.cells]
 functions.append(dict(code=f'LNP-{i:02}',platform=c[1],group=c[2],name=c[3],requirement=c[4],rule=c[5]))
functions.extend([
 dict(code='LNP-15',platform='Xử lý nền',group='Quỹ phép',name='Cấp và hết hạn quỹ phép',requirement='Cấp quỹ đúng thời điểm, loại quỹ và năm nguồn.',rule='BR-01 đến BR-06; không cấp lại quỹ đã hết hạn.'),
 dict(code='LNP-16',platform='Xử lý nền',group='Quản lý yêu cầu',name='Tự hủy yêu cầu liên quan phép cũ hết hạn',requirement='Xử lý các yêu cầu Chờ duyệt khi qua 31/03.',rule='BR-15, BR-16; hủy toàn bộ yêu cầu, hoàn phần phép mới còn hạn; nếu là đề nghị thì giữ đơn gốc.')])

rules=[
('BR-01','Phép năm cơ bản tối đa 12 ngày/năm; cấp 1 ngày vào đầu tháng. Vào làm ngày 15/08 thì đến 01/09 ghi nhận 1 ngày, không cộng tháng 8.'),
('BR-02','Phép năm tích lũy trong thử việc; ký HĐLĐ chính thức mới chuyển phần còn hạn vào quỹ sử dụng. Không sử dụng quỹ tích lũy đã quá hạn.'),
('BR-03','Mỗi đủ 5 năm thâm niên cộng ngay 1 ngày phép; 10 năm cộng 2 ngày. Nguồn và ngày tính thâm niên: '),
('BR-04','Nghỉ dưỡng 3 ngày, cấp từ đầu năm sau năm vào làm. Nếu còn thử việc thì tích lũy đến khi ký chính thức. Hết hạn 31/12, không dùng lại quỹ năm trước đã hết hạn.'),
('BR-05','Phép dư năm trước được dùng đến hết 31/03 năm sau; ưu tiên dùng phép cũ cho ngày nghỉ trong hạn. Từ 01/04 dùng phép năm hiện tại; xét theo ngày nghỉ, không theo ngày gửi/duyệt.'),
('BR-06','Kiểm tra quỹ đã được cấp tại thời điểm gửi; không sử dụng quỹ dự kiến. Đơn qua 31/12 phải đủ quỹ đã cấp của từng năm nguồn.'),
('BR-07','Mỗi đơn một loại nghỉ; một đơn phép năm có thể dùng nhiều nguồn phép cũ/mới. Không tự chuyển sang nghỉ dưỡng/không lương khi phép năm thiếu.'),
('BR-08','Tính theo nửa ngày và lịch làm việc có hiệu lực. Cuối tuần và lễ/Tết được loại trừ; ngày làm bù được tính là ngày làm việc. Ngày nghỉ bù lễ và mốc sáng/chiều: '),
('BR-09','Nghỉ không lương bắt buộc chọn Có thỏa thuận / Không thỏa thuận; không trừ quỹ phép năm hoặc nghỉ dưỡng.'),
('BR-10','Chặn gửi hoặc cập nhật nếu thiếu quỹ hoặc trùng thời gian với đơn Chờ duyệt/Đã duyệt. Bỏ qua đơn Từ chối/Đã hủy. Khi sửa không hợp lệ, giữ đơn, quỹ và bước duyệt cũ.'),
('BR-11','Đơn hợp lệ trừ quỹ áp dụng lúc gửi. Sửa đơn chưa duyệt hoàn tất cập nhật ngay và duyệt lại từ cấp 1, kể cả cấp 1 đã duyệt trước đó; giữ kết quả cũ trong lịch sử.'),
('BR-12','Sửa/hủy đơn đã duyệt phải gửi đề nghị Chờ duyệt, phân biệt bằng loại Điều chỉnh/Hủy; giữ bản đơn gốc đã duyệt. Sửa điều chỉnh quỹ lúc gửi; hủy chưa hoàn quỹ.'),
('BR-13','Duyệt sửa: cập nhật đơn gốc; từ chối: giữ bản đơn cũ và khôi phục quỹ theo đơn cũ. Duyệt hủy: đơn gốc Đã hủy; từ chối: giữ đơn và quỹ cũ.'),
('BR-14','Hoàn/khôi phục theo từng nguồn quỹ. Phép cũ còn hạn được hoàn; đã hết hạn không trở lại quỹ khả dụng. Chỉ hoàn phần quỹ còn hạn, không cấp lại quỹ cũ.'),
('BR-15','Qua 31/03 tự hủy toàn bộ đơn đăng ký Chờ duyệt liên quan phép cũ, kể cả dùng cả phép cũ và mới. Trạng thái Đã hủy, lý do Phép cũ hết hạn; chỉ hoàn phần phép mới còn hạn.'),
('BR-16','Quy tắc tự hủy cũng áp dụng đề nghị sửa/hủy Chờ duyệt liên quan phép cũ; hủy đề nghị, giữ đơn gốc; xử lý khôi phục quỹ theo nguồn còn hạn.'),
('BR-17','Duyệt tuần tự theo loại công nghỉ và PL02 trong DB; một cấp từ chối thì kết thúc yêu cầu. Có xử lý nhiều đơn. Quy tắc khi một đơn trong nhóm không hợp lệ: '),
('BR-18','PL02: phép năm, nghỉ dưỡng hàng năm, nghỉ việc riêng hưởng lương do QLTT duyệt. Nghỉ không lương: QLTT → Trưởng phòng TCLĐ. Nhân sự Dự án nước ngoài áp dụng đầu mối riêng theo PL02.'),
('BR-19','Nghỉ không lương có thỏa thuận cần HR SSC trình ký; chỉ hoàn tất sau ký thành công. Không thỏa thuận hoàn tất sau duyệt đủ cấp. Tích hợp, tên trạng thái và xử lý lỗi ký: '),
('BR-20','Được sửa/hủy sau thời gian nghỉ, nhưng trước chốt công tháng. Công đã chốt hoặc đơn đã đến bước trình ký thì khóa sửa/hủy.'),
('BR-21','Danh mục loại nghỉ, quy tắc quỹ và luồng duyệt cấu hình trong DB; không bổ sung UI quản lý loại nghỉ. Không giả lập kết quả trình ký.'),
('BR-22','PL01: nghỉ phép không chấm cho thử việc/tập nghề; nghỉ dưỡng hàng năm không áp dụng thử việc, tập nghề, chờ thôi việc, tạm hoãn HĐLĐ. Chi tiết áp dụng cho tập nghề trên Happy Connect: '),
('BR-23','Theo quy trình cung cấp, nghỉ có kế hoạch phải được duyệt trước khi nghỉ; nghỉ đột xuất hoàn thiện đăng ký ngày làm việc đầu tiên trở lại. Phạm vi TCLĐ hỗ trợ nhập trên Happy Connect: '),
]

doc.add_paragraph('TÀI LIỆU ĐẶC TẢ YÊU CẦU','Title')
doc.add_paragraph('Chức năng quản lý yêu cầu nghỉ phép','Title')
p('Happy Connect và Web HRM')
p('Phiên bản 0.1 • Khung để chỉnh sửa và bổ sung')
table(['Thông tin','Giá trị'],[
 ('Mã tài liệu',''),('Tên tài liệu','SRS Quản lý yêu cầu nghỉ phép'),('Ngày lập','13/10/2026'),
 ('Đơn vị biên soạn',''),('Người biên soạn',''),('Ngày ban hành',''),('Trạng thái phê duyệt','')],[2,4.75])
p('Các ô chưa có thông tin được để trống. Mã LNP, BR, SC và AC dùng để liên kết nội dung trong tài liệu; có thể điều chỉnh theo quy ước dự án.')
page(); h('BẢNG GHI NHẬN THAY ĐỔI TÀI LIỆU')
table(['Phiên bản','Ngày','Nội dung thay đổi','Người cập nhật'],[('0.1','13/10/2026','Khởi tạo khung SRS và điền quy tắc đã xác nhận.',''),('','','','')],[.65,.9,3.9,1.3])
h('XÁC NHẬN TÀI LIỆU')
table(['Vai trò','Họ tên và đơn vị','Chữ ký','Ngày'],[(x,'','','') for x in ['Biên soạn','Kiểm tra nghiệp vụ','Kiểm tra kỹ thuật','Phê duyệt']],[1.45,2.7,1.3,1.3])
h('MỤC LỤC NỘI DUNG')
for x in ['I Giới thiệu','II Tổng quan chức năng và quy tắc nghiệp vụ','III Đặc tả chi tiết chức năng','IV Yêu cầu phi chức năng và tích hợp','V Tiêu chuẩn nghiệm thu','VI Nội dung cần bổ sung']: p(x)

page(); h('I GIỚI THIỆU')
h('I.1 Mục đích',2)
p('Đặc tả yêu cầu đăng ký, theo dõi, phê duyệt, sửa/hủy nghỉ phép và quản lý quỹ liên quan. Tài liệu phục vụ rà soát nghiệp vụ, thiết kế, phát triển, kiểm thử và nghiệm thu.')
h('I.2 Phạm vi',2)
p('Happy Connect: đăng ký và theo dõi đơn cá nhân, tạm tính quỹ, sửa/hủy và phê duyệt. Web HRM: tra cứu, xem quỹ phục vụ duyệt, phê duyệt đơn và xuất dữ liệu theo prototype.')
p('Phạm vi thay đổi đã xác nhận là Happy Connect. Phạm vi điều chỉnh nghiệp vụ, dữ liệu dùng chung và xử lý đề nghị sửa/hủy tương ứng trên Web HRM:')
p()
p('Giới hạn giao diện Happy Connect: giữ nguyên UI/UX, layout, spacing, màu sắc, typography, component, route và các màn hình khác; tái sử dụng popup/biểu mẫu. Đổi tên tab Đơn của tôi thành Đăng ký. Yêu cầu này là yêu cầu giao diện, không phải chức năng nghiệp vụ riêng.')
h('I.3 Tác nhân và thuật ngữ',2)
table(['Tác nhân hoặc thuật ngữ','Vai trò hoặc ý nghĩa'],[
 ('CBNV / Nhân viên','Đăng ký, theo dõi và đề nghị sửa/hủy đơn của mình.'),('QLTT','Quản lý trực tiếp; xử lý theo luồng và phạm vi được giao.'),
 ('Trưởng phòng TCLĐ','Cấp duyệt tiếp theo đối với nghỉ không lương theo PL02.'),('HR SSC','Thực hiện trình ký đối với loại nghỉ có yêu cầu; màn hình và tích hợp chưa chốt.'),
 ('Quỹ năm nguồn','Phân biệt phép cũ, phép mới và hạn sử dụng tương ứng.'),('Đơn gốc / Đề nghị','Đơn đã duyệt và yêu cầu Điều chỉnh/Hủy liên kết với đơn đó.')],[1.75,5])
h('I.4 Tài liệu tham khảo',2)
table(['Tài liệu','Vai trò tham khảo'],[
 ('SRS_QLVR_Cham_cong_v1.1_12102026','Cấu trúc tổng quan, đặc tả chức năng và dữ liệu.'),('VTIT_SRS - Happy Connect - Common','Cấu trúc mô tả thành phần UI, quy tắc giao diện và phi chức năng.'),
 ('Mẫu tài liệu URD','Cách tổ chức quy trình, tác nhân và danh sách yêu cầu.'),('SRS_Chuc_nang_quan_ly_mo_cua_ngoai_gio','Khung một chức năng: quản trị tài liệu, luồng, ngoại lệ, dữ liệu và nghiệm thu.'),
 ('PL01, PL02 và QT.00.TCNL.20 lần 07','Loại công nghỉ, thẩm quyền, luồng duyệt và bước trình ký.'),('Prototype và báo cáo sơ bộ nghỉ phép','Màn hình và nội dung nghiệp vụ đã trao đổi, xác nhận.')],[3.45,3.3])

page(); h('II TỔNG QUAN CHỨC NĂNG VÀ QUY TẮC NGHIỆP VỤ')
h('II.1 Danh sách chức năng',2)
table(['Mã','Nền tảng','Chức năng','CR hoặc Làm mới','Ưu tiên'],[(f['code'],f['platform'],f['name'],'','') for f in functions],[.65,1.5,3.3,.85,.45])
h('II.2 Mô hình giao tiếp và phụ thuộc',2)
table(['Thành phần','Dữ liệu nghiệp vụ','Nguồn hoặc cơ chế'],[
 ('Nhân sự và hợp đồng','Ngày vào làm, HĐLĐ chính thức, thâm niên, đơn vị, quản lý',''),('Lịch làm việc và lễ/Tết','Lịch có hiệu lực, ngày làm bù, ngày nghỉ bù lễ',''),
 ('Chốt công','Kỳ công và thời điểm khóa sửa/hủy',''),('DB cấu hình','Loại nghỉ, quy tắc quỹ, luồng duyệt',''),('S4/V-Office','Hồ sơ và kết quả trình ký','')],[1.7,3.25,1.8])
page(); h('II.3 Quy tắc nghiệp vụ',2)
table(['Mã','Nội dung đã xác nhận và ô cần bổ sung'],rules,[.75,6])

page(); h('II.4 Workflow tạo mới và phê duyệt',2)
pic('Workflow tạo mới nghỉ phép swimlane.png')
p('Trình ký là bước nghiệp vụ của HR SSC. Phương thức tích hợp và xử lý kết quả ký chưa thành công:')
page(); h('II.5 Workflow đề nghị sửa hoặc hủy',2)
pic('Workflow sửa hủy nghỉ phép swimlane.png')
p('Đơn chưa duyệt hoàn tất sửa ngay và duyệt lại từ cấp 1. Đề nghị sửa/hủy đơn đã duyệt giữ bản đơn gốc để xử lý khôi phục.')
page(); h('II.6 Biểu đồ trạng thái',2)
pic('Biểu đồ trạng thái đơn nghỉ phép cập nhật.png')
pic('Biểu đồ trạng thái đề nghị sửa hủy cập nhật.png')
page(); h('II.7 Ma trận trạng thái và điều kiện thao tác',2)
table(['Đối tượng / trạng thái','Thao tác','Kết quả','Điều kiện'],[
 ('Đơn / Chờ duyệt','Sửa','Chờ duyệt, quay về cấp 1','Hợp lệ; chưa khóa.'),('Đơn / Chờ duyệt','Hủy','Đã hủy; hoàn quỹ còn hạn','Chưa khóa.'),
 ('Đơn / Chờ duyệt','Duyệt một cấp','Chờ duyệt ở cấp tiếp theo','Còn cấp theo cấu hình.'),('Đơn / Chờ duyệt','Duyệt đủ cấp','Đã duyệt','Nếu cần ký thì chưa hoàn tất.'),
 ('Đơn / Chờ duyệt','Từ chối','Từ chối; hoàn quỹ còn hạn','Ghi lý do, người và thời gian.'),('Đơn / Đã duyệt','Sửa hoặc hủy','Tạo đề nghị Chờ duyệt','Giữ bản gốc; chưa khóa.'),
 ('Đề nghị / Chờ duyệt','Từ chối','Đề nghị Từ chối; giữ đơn gốc','Sửa: khôi phục quỹ theo nguồn.'),('Đề nghị / Chờ duyệt','Duyệt đủ cấp','Đề nghị Đã duyệt','Sửa: cập nhật đơn; hủy: đơn gốc Đã hủy.'),
 ('Đơn hoặc đề nghị / Chờ duyệt','Qua 31/03','Đã hủy toàn bộ yêu cầu','Có liên quan phép cũ; BR-15, BR-16.'),('Đơn đến trình ký / công đã chốt','Sửa hoặc hủy','Không được thực hiện','BR-20.'),
 ('Nghỉ không lương có thỏa thuận','Ký thành công','Hoàn tất lần xử lý','Tên trạng thái chờ ký: ')],[1.65,1,2.05,2.05])
h('II.8 Khung thông báo',2)
table(['Sự kiện','Người nhận','Kênh','Nội dung / thời điểm'],[(x,'','','') for x in ['Gửi đơn','Duyệt hoặc từ chối','Sửa hoặc hủy','Tự hủy do phép cũ hết hạn','Kết quả trình ký']],[1.65,1.3,1.1,2.7])

page(); h('III ĐẶC TẢ CHI TIẾT CHỨC NĂNG')
p('Mỗi chức năng có bảng thông tin chung, luồng xử lý và khung mô tả giao diện/dữ liệu. Bổ sung màn hình, trường, ràng buộc và thông báo vào các ô trống; giữ mã tham chiếu khi cập nhật.')

flows={
 1:('Nhân viên','Mở tab Đăng ký.','1. Hệ thống lấy danh sách đơn của nhân viên.\n2. Hiển thị thông tin và trạng thái.\n3. Người dùng mở chi tiết hoặc tạo đơn.','Danh sách cá nhân.','BR-09, BR-12'),
 2:('Nhân viên','Nhấn tạo yêu cầu mới.','1. Chọn loại nghỉ, hình thức không lương nếu có.\n2. Nhập thời gian và thông tin; xem tạm tính.\n3. Gửi: kiểm tra quỹ đã cấp và trùng lịch.\n4. Hợp lệ: trừ quỹ áp dụng, tạo Chờ duyệt và chuyển cấp đầu.','Đơn Chờ duyệt, nguồn quỹ đã trừ.','BR-05 đến BR-11, BR-18, BR-23'),
 3:('Nhân viên','Chọn loại nghỉ hoặc thay đổi thời gian.','1. Xác định nửa ngày làm việc hợp lệ.\n2. Phân bổ nguồn quỹ còn hạn theo ngày nghỉ.\n3. Hiển thị số ngày, quỹ và dự kiến còn lại.','Số ngày và phân bổ tạm tính.','BR-01 đến BR-10'),
 4:('Nhân viên','Chọn sửa hoặc đề nghị điều chỉnh.','1. Kiểm tra khóa chốt công/trình ký.\n2. Nhập sửa và lý do; kiểm tra quỹ/trùng lịch.\n3. Chưa duyệt hoàn tất: cập nhật ngay, quay về cấp 1.\n4. Đã duyệt: tạo đề nghị Điều chỉnh, điều chỉnh quỹ lúc gửi.','Đơn cập nhật hoặc đề nghị Chờ duyệt.','BR-10 đến BR-14, BR-20'),
 5:('Nhân viên','Chọn hủy, nhập lý do và xác nhận.','1. Kiểm tra điều kiện khóa.\n2. Chưa duyệt hoàn tất: hủy ngay, hoàn nguồn còn hạn.\n3. Đã duyệt: gửi đề nghị Hủy, chưa hoàn quỹ.','Đơn Đã hủy hoặc đề nghị Chờ duyệt.','BR-12 đến BR-14, BR-20'),
 6:('Nhân viên','Mở lịch sử trong chi tiết.','1. Lấy các lần xử lý của đơn và đề nghị.\n2. Hiển thị người, thời gian, thao tác, kết quả và lý do.','Lịch sử xử lý.','BR-11 đến BR-13'),
 7:('Người duyệt theo PL02','Mở đề nghị Điều chỉnh hoặc Hủy.','1. Kiểm tra phạm vi và cấp hiện tại.\n2. Duyệt tuần tự hoặc từ chối có lý do.\n3. Duyệt sửa: áp dụng nội dung; duyệt hủy: hủy đơn gốc.\n4. Từ chối: giữ bản gốc và khôi phục quỹ sửa theo nguồn.','Kết quả đề nghị và cập nhật đơn gốc.','BR-12 đến BR-20'),
 8:('Nhân viên / Người duyệt','Nhập điều kiện tìm kiếm hoặc bộ lọc.','1. Nhập tiêu chí theo nền tảng.\n2. Áp dụng điều kiện và phạm vi xem.\n3. Hiển thị kết quả; đặt lại khi yêu cầu.','Danh sách theo tiêu chí.',''),
 9:('Nhân viên / Người duyệt','Chọn một yêu cầu.','1. Kiểm tra phạm vi truy cập.\n2. Hiển thị nội dung, quỹ và thông tin duyệt.\n3. Hiển thị thao tác tương ứng với vai trò, trạng thái và khóa.','Chi tiết yêu cầu.','BR-09, BR-12, BR-20'),
 10:('Người duyệt theo PL02','Mở danh sách phê duyệt.','1. Lấy yêu cầu trong phạm vi được giao.\n2. Happy Connect có nhóm Đơn nghỉ phép, Đề nghị điều chỉnh, Đề nghị hủy.\n3. Web HRM hiển thị bảng và phân trang theo prototype.','Danh sách cần xử lý.','BR-17, BR-18'),
 11:('Người duyệt theo PL02','Nhấn duyệt hoặc từ chối.','1. Kiểm tra quyền, trạng thái và cấp hiện tại.\n2. Xác nhận; từ chối bắt buộc lý do.\n3. Duyệt chuyển cấp hoặc Đã duyệt; từ chối kết thúc và hoàn nguồn còn hạn.\n4. Có thỏa thuận: chỉ hoàn tất sau ký thành công.','Kết quả xử lý và lịch sử.','BR-14, BR-17 đến BR-19'),
 12:('Người duyệt theo PL02','Chọn nhiều yêu cầu và nhấn xử lý.','1. Chọn bản ghi và hiển thị số lượng.\n2. Xác nhận thao tác, nhập lý do nếu từ chối.\n3. Áp dụng đúng cấp duyệt cho từng đơn.\n4. Web chỉ chọn đơn được giao trên trang hiện tại.','Kết quả theo từng đơn.','BR-17'),
 13:('Người duyệt Web HRM','Mở danh sách hoặc chi tiết yêu cầu.','1. Lấy chỉ tiêu quỹ của nhân sự liên quan.\n2. Hiển thị Được cấp, Đã sử dụng, Yêu cầu nghỉ, Còn lại.','Thông tin quỹ phục vụ duyệt.','Phạm vi áp dụng BR trên Web: '),
 14:('Người dùng Web HRM','Nhấn Xuất file.','1. Tiếp nhận thao tác xuất.\n2. Phạm vi dữ liệu, định dạng và bộ cột: \n3. Cung cấp kết quả xuất theo đặc tả được bổ sung.','File xuất; định dạng: ','') ,
 15:('Hệ thống','Đầu tháng/đầu năm, ký HĐLĐ hoặc đủ mốc thâm niên.','1. Xác định loại quỹ, năm nguồn và điều kiện nhân sự.\n2. Cấp hoặc chuyển quỹ tích lũy còn hạn theo BR.\n3. Ghi số ngày và hạn sử dụng; không cấp lại quỹ hết hạn.','Quỹ khả dụng theo nguồn.','BR-01 đến BR-06'),
 16:('Hệ thống','Qua hạn 31/03.','1. Xác định đơn/đề nghị Chờ duyệt liên quan phép cũ.\n2. Hủy toàn bộ yêu cầu, ghi lý do Phép cũ hết hạn.\n3. Hoàn/khôi phục nguồn còn hạn; đề nghị bị hủy giữ đơn gốc.','Đã hủy và quỹ theo nguồn.','BR-14 đến BR-16'),
}
for i,f in enumerate(functions,1):
 page(); h(f"III.{i} {f['code']} {f['name']}",2)
 actor,event,main,result,br=flows[i]
 table(['Nội dung','Mô tả'],[
 ('Mã chức năng',f['code']),('Tên chức năng',f['name']),('Nền tảng',f['platform']),('Mức độ ưu tiên / CR hoặc Làm mới',''),
 ('Tần suất sử dụng',''),('Tác nhân',actor),('Sự kiện kích hoạt',event),('Điều kiện kích hoạt','Đăng nhập và có phạm vi/quyền phù hợp. Điều kiện bổ sung: ' if i<15 else ''),
 ('Luồng chính',main),('Luồng thay thế',''),('Luồng ngoại lệ',''),('Nghiệp vụ và quy tắc',f['rule']),('Kết quả đầu ra',result),('Quy tắc tham chiếu',br),('Màn hình / mã SC','')],[1.7,5.05])
 h('a. Thiết kế giao diện',3); p('Hình hoặc liên kết màn hình:'); p()
 h('b. Mô tả chi tiết giao diện và dữ liệu',3)
 table(['STT','Tên trường / thao tác','Kiểu dữ liệu','Bắt buộc','Khởi tạo','Mô tả / ràng buộc','CSDL'],[('','','','','','',''),('','','','','','','')],[.3,1.3,.85,.55,.65,2.6,.5])
 p('Thông báo, mã lỗi và tiêu chí nghiệm thu bổ sung:'); p()

page(); h('III.17 Khung dữ liệu form đăng ký và chỉnh sửa',2)
fields=[
 ('Loại nghỉ','Danh mục','Có','','Theo DB; mỗi đơn một loại nghỉ.'),('Hình thức không lương','Lựa chọn','Có khi không lương','Trống','Có thỏa thuận / Không thỏa thuận; ẩn với loại khác.'),
 ('Từ ngày giờ','Ngày giờ','','','Mốc nửa ngày và giới hạn nhập: '),('Đến ngày giờ','Ngày giờ','','','Ràng buộc thời gian chi tiết: '),('Lý do nghỉ','Văn bản','Có','','Giới hạn độ dài: '),
 ('Nơi nghỉ','Văn bản','','',''),('Người tiếp nhận công việc','Nhân sự','Có','','Nguồn danh sách và phạm vi: '),('Tệp đính kèm','Tệp','Theo PL02','','Loại tệp, dung lượng, số lượng: '),
 ('Lý do điều chỉnh','Văn bản','Có khi sửa','',''),('Lý do hủy','Văn bản','Có khi hủy','',''),('Lý do từ chối','Văn bản','Có khi từ chối','',''),('Luồng duyệt','Hiển thị','','','Theo DB và PL02.')]
table(['STT','Tên trường','Kiểu dữ liệu','Bắt buộc','Khởi tạo','Ràng buộc','CSDL'],[(str(i),*r,'') for i,r in enumerate(fields,1)],[.3,1.35,.8,.65,.6,2.55,.5])
h('III.18 Danh mục màn hình',2)
table(['Mã','Nền tảng','Màn hình / popup','Đặc tả cần bổ sung'],[
 ('SC-01','Happy Connect','Đăng ký / danh sách cá nhân',''),('SC-02','Happy Connect','Tạo / chỉnh sửa đơn',''),('SC-03','Happy Connect','Chi tiết và lịch sử',''),
 ('SC-04','Happy Connect','Phê duyệt và các nhóm đề nghị',''),('SC-05','Happy Connect','Popup duyệt / từ chối / hủy',''),('SC-06','Web HRM','Danh sách quản lý nghỉ phép',''),('SC-07','Web HRM','Chi tiết và phê duyệt','')],[.65,1.35,2.6,2.15])

page(); h('IV YÊU CẦU PHI CHỨC NĂNG VÀ TÍCH HỢP')
p('Tham khảo các nhóm yêu cầu trong mẫu Common. Chỉ điền thông số và chính sách đã được dự án xác nhận; không tự sao chép giá trị của chức năng khác.')
table(['Nhóm yêu cầu','Nội dung cần đặc tả','Giá trị hoặc quyết định'],[
 ('Bảo mật / phân quyền','Vai trò, phạm vi nhân sự, dữ liệu đơn và quyền thao tác',''),('Hiệu năng','Thời gian phản hồi; người dùng đồng thời; tải cấp quỹ/tự hủy',''),
 ('Ổn định / sẵn sàng','Mức sẵn sàng, xử lý gián đoạn và khôi phục',''),('Sao lưu / lưu trữ','Chu kỳ sao lưu; thời gian lưu đơn, tệp và lịch sử',''),
 ('Nhất quán giao dịch','Gửi/sửa/duyệt đồng thời; chống trừ/hoàn/cấp quỹ lặp',''),('Giao diện dùng chung','Áp dụng Common trong phạm vi thành phần hiện có; ngoại lệ',''),
 ('Ghi log / vận hành','Nội dung log, đầu mối hỗ trợ và xử lý tác vụ lỗi','')],[1.45,3.8,1.5])
h('IV.1 Khung đặc tả tích hợp',2)
table(['Thành phần','Sự kiện / dữ liệu','API hoặc giao thức','Lỗi / retry / đối soát'],[
 ('Nhân sự / HĐLĐ','Ngày vào làm, ký chính thức, thâm niên, QLTT','',''),('Lịch làm việc','Lễ/Tết, làm bù, nghỉ bù','',''),('Chốt công','Kỳ công và trạng thái khóa','',''),
 ('S4/V-Office','Trình ký và kết quả ký','',''),('Web HRM / DB chung','Phạm vi dùng chung và đồng bộ quỹ/đơn','','')],[1.35,2.4,1.4,1.6])

page(); h('V TIÊU CHUẨN NGHIỆM THU')
acs=[
 ('LNP-02','Gửi đơn không lương khi chưa chọn hình thức','Chặn gửi; yêu cầu lựa chọn.'),('LNP-02','Quỹ đã cấp không đủ dù quỹ tương lai dự kiến đủ','Chặn; không tạo đơn hoặc trừ quỹ.'),
 ('LNP-02','Trùng đơn Chờ duyệt hoặc Đã duyệt','Chặn; đơn Từ chối/Đã hủy không tính trùng.'),('LNP-03','Ngày nghỉ sau 31/03','Không sử dụng phép dư năm trước.'),
 ('LNP-03','Khoảng nghỉ có cuối tuần, lễ và ngày làm bù','Tính theo lịch có hiệu lực; ngày làm bù tính công nghỉ.'),('LNP-04','Cấp 1 đã duyệt, sửa khi chờ cấp 2','Sửa hợp lệ: quay về cấp 1; giữ kết quả trước trong lịch sử.'),
 ('LNP-04','Sửa làm thiếu quỹ hoặc trùng lịch','Giữ nguyên đơn, quỹ và bước duyệt cũ.'),('LNP-04/05','Công đã chốt hoặc đến trình ký','Chặn sửa/hủy.'),
 ('LNP-07','Từ chối đề nghị sửa','Giữ đơn gốc; khôi phục quỹ theo nguồn, không hồi sinh phép hết hạn.'),('LNP-05/07','Hủy sau hạn phép cũ','Chỉ hoàn phần nguồn còn hạn.'),
 ('LNP-11','Một cấp từ chối đơn','Kết thúc và ghi lý do, người, thời gian; hoàn nguồn còn hạn.'),('LNP-11','Không lương có thỏa thuận đã duyệt đủ cấp','Chưa hoàn tất trước khi ký thành công.'),
 ('LNP-15','Vào làm 15/08, xử lý ngày 01/09','Ghi nhận 1 ngày tháng 9; không cộng tháng 8.'),('LNP-15','Ký HĐLĐ chính thức sau khi quỹ cũ hết hạn','Không chuyển quỹ quá hạn thành khả dụng.'),
 ('LNP-16','Qua 31/03, đơn Chờ duyệt dùng cả phép cũ/mới','Hủy toàn bộ; chỉ hoàn phần phép mới còn hạn.'),('LNP-16','Đề nghị sửa/hủy liên quan phép cũ còn chờ','Hủy đề nghị, giữ đơn gốc, xử lý quỹ theo nguồn.'),
 ('LNP-14','Xuất dữ liệu trên Web HRM','Bộ cột, định dạng, phạm vi dữ liệu: ')]
table(['Mã','Chức năng','Tình huống','Kết quả mong đợi','Kết quả thực tế'],[(f'AC-{i:02}',*r,'') for i,r in enumerate(acs,1)],[.6,.9,2.1,2.25,.9])
h('V.1 Bổ sung tiêu chí nghiệm thu',2)
table(['Mã','Yêu cầu / chức năng','Tình huống','Kết quả mong đợi'],[('','','',''),('','','','')],[.65,1.45,2.25,2.4])

page(); h('VI NỘI DUNG CẦN BỔ SUNG')
items=[
 'Phạm vi thay đổi Web HRM, dữ liệu chung và duyệt đề nghị sửa/hủy trên Web.',
 'Ngày nghỉ bù lễ; mốc sáng/chiều; trường hợp khoảng nghỉ không có ngày làm việc.',
 'Cấp phép khi vào làm đúng ngày đầu tháng; nguồn tính thâm niên; áp dụng với tập nghề.',
 'Trình ký: tên trạng thái, API/cơ chế, thất bại, từ chối và gửi lại.',
 'Nguồn và thời điểm chốt công; đơn qua nhiều kỳ công; sửa/hủy khi một kỳ đã khóa.',
 'Nhiều đề nghị đồng thời trên một đơn; xử lý giao dịch song song; tác vụ chạy lại.',
 'Duyệt hàng loạt khi một đơn không hợp lệ; thay người duyệt hoặc ủy quyền.',
 'Định dạng/bộ cột xuất; tệp đính kèm; giới hạn nhập; thông báo và nội dung lỗi.',
 'Phân tách quỹ cũ/mới trên UI; từ chối/hủy sửa loại nghỉ; xử lý phần chênh lệch quỹ.',
 'Thông số phi chức năng, lưu log/tệp, hỗ trợ và vận hành; quản trị và phê duyệt tài liệu.']
table(['STT','Nội dung cần bổ sung','Quyết định','Người / ngày xác nhận'],[(str(i),s,'','') for i,s in enumerate(items,1)],[.4,3.5,1.4,1.45])
doc.core_properties.title='SRS Quản lý yêu cầu nghỉ phép'
doc.core_properties.author=''; doc.core_properties.subject='Khung SRS Happy Connect và Web HRM'
dest=out/'Form SRS Quản lý yêu cầu nghỉ phép.docx'; doc.save(dest)
with ZipFile(dest) as z: assert z.testzip() is None
check=Document(dest)
assert len(check.inline_shapes)==4
text='\n'.join(p.text for p in check.paragraphs)+'\n'+'\n'.join(c.text for t in check.tables for r in t.rows for c in r.cells)
assert 'mở cửa ngoài giờ' not in text.lower()
assert all(f['code'] in text for f in functions)
assert all(code in text for code,_ in rules)
assert 'TBD' not in text
assert hashlib.sha256(ref.read_bytes()).hexdigest()=='11bf2d7aab95ee1bc10d5f848ca56384635fa60d9af117224db596e5d5fb9283'
(root/'work'/'srs-artifact.md').write_text('Reference: '+str(ref)+'\nSHA256: 11bf2d7aab95ee1bc10d5f848ca56384635fa60d9af117224db596e5d5fb9283\nBase geometry and Arial styles retained. Body rewritten for leave SRS; header/footer renamed; unrelated source content removed. Sample structures combined: 5 SRS chapters + open items, 2-column functional specs, 7-column UI data form. 16 editable function forms, 23 BR, 17 AC; 4 diagrams retained. Unknown values intentionally blank. Bundled renderer unavailable because soffice.exe is missing; no full-page visual QA claim.\n',encoding='utf8')
print(dest)
print('Verified: 16 function forms; 23 business rules; 17 acceptance cases; 4 diagrams; editable blank fields.')
