from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
import math

ROOT=Path.cwd(); WORK=ROOT/'work'; OUT=ROOT/'outputs'
font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',32)
small=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',27)
bold=ImageFont.truetype('C:/Windows/Fonts/arialbd.ttf',32)
colors={'task':('#edf4ff','#799bc8'),'wait':('#fff4cf','#d7ad45'),'ok':('#e8f4df','#86ad69'),'no':('#ffe9e9','#d07676'),'white':('#ffffff','#799bc8')}
def new(w,h):
 im=Image.new('RGB',(w,h),'white'); return im,ImageDraw.Draw(im)
def text(draw,x,y,s,f=font,color='#182b49',bg=False):
 lines=s.split('\n'); boxes=[draw.textbbox((0,0),l,font=f) for l in lines]
 width=max((b[2]-b[0] for b in boxes),default=0); ht=len(lines)*(f.size+8)
 if bg: draw.rounded_rectangle((x-width/2-8,y-ht/2-3,x+width/2+8,y+ht/2+3),radius=6,fill='white')
 for i,l in enumerate(lines):
  b=boxes[i]; draw.text((x-(b[2]-b[0])/2,y-ht/2+i*(f.size+8)-b[1]),l,font=f,fill=color)
def box(draw,x,y,w,h,s,kind='task'):
 fill,stroke=colors[kind]; draw.rounded_rectangle((x-w/2,y-h/2,x+w/2,y+h/2),radius=20,fill=fill,outline=stroke,width=3); text(draw,x,y,s)
def event(draw,x,y,s):
 draw.ellipse((x-18,y-18,x+18,y+18),fill='#315b96'); text(draw,x,y+49,s,small)
def arrow(draw,points,label='',at=None):
 draw.line(points,fill='#7a879a',width=3,joint='curve'); a,b=points[-2:]; ang=math.atan2(b[1]-a[1],b[0]-a[0]); size=13
 draw.polygon([b,(b[0]-size*math.cos(ang-.5),b[1]-size*math.sin(ang-.5)),(b[0]-size*math.cos(ang+.5),b[1]-size*math.sin(ang+.5))],fill='#7a879a')
 if label and at: text(draw,*at,label,small,bg=True)

# Horizontal workflow with a second row for the review and signature branches.
im,d=new(1600,1130)
event(d,40,140,'Start')
for x,s in [(250,'Mở tab Đăng ký\nTạo yêu cầu mới'),(620,'Chọn loại nghỉ\nNghỉ không lương:\nchọn hình thức'),(1000,'Nhập thời gian, lý do\nNgười tiếp nhận việc\nNơi nghỉ, hồ sơ PL02'),(1390,'Xem tạm tính\nQuỹ và luồng duyệt')]: box(d,x,140,330 if x!=1390 else 350,150,s)
arrow(d,[(60,140),(85,140)])
for x1,x2 in [(415,455),(785,835),(1165,1215)]: arrow(d,[(x1,140),(x2,140)])
box(d,1390,390,350,135,'Gửi yêu cầu','wait'); arrow(d,[(1390,215),(1390,322)])
box(d,1000,390,330,150,'Chờ duyệt\nTrừ quỹ áp dụng\nKhông trừ nếu Ro','wait'); arrow(d,[(1215,390),(1165,390)])
box(d,620,390,330,150,'Duyệt theo PL02\nTuần tự từng cấp\nXử lý một / nhiều đơn')
arrow(d,[(835,390),(785,390)])
box(d,250,390,330,150,'Từ chối\nNhập lý do\nHoàn quỹ đã trừ','no')
arrow(d,[(455,390),(415,390)],'Từ chối',(435,320))
box(d,620,690,330,125,'Đã duyệt đủ cấp','ok')
arrow(d,[(620,465),(620,627)],'Duyệt đủ cấp',(620,550))
box(d,1050,690,440,150,'Không lương có thỏa thuận\nHR SSC trình ký\nChưa hoàn tất khi chưa ký')
arrow(d,[(785,690),(830,690)],'Có thỏa thuận',(810,610))
box(d,1050,970,440,125,'Trình ký thành công','ok'); arrow(d,[(1050,765),(1050,907)])
event(d,620,970,'End')
arrow(d,[(620,752),(620,950)],'Không cần ký',(620,837))
arrow(d,[(830,970),(642,970)],'Hoàn tất',(745,930))
arrow(d,[(250,465),(250,970),(598,970)])
text(d,810,1090,'Nghỉ không lương: QLTT → Trưởng phòng TCLĐ. Phương thức tích hợp trình ký: chưa chốt.',small)
im.save(WORK/'workflow-nghi-phep.png')

# Main states on one line; proposal states and terminal alternatives on the sides.
im,d=new(1600,1470)
event(d,40,480,'Start')
box(d,330,480,390,135,'Chờ duyệt','wait')
box(d,1050,480,440,135,'Đã duyệt','ok')
arrow(d,[(60,480),(135,480)],'NV / Gửi đơn',(100,385))
arrow(d,[(525,480),(830,480)],'Người duyệt / Duyệt đủ cấp',(680,395))
box(d,330,790,390,135,'Từ chối','no')
arrow(d,[(330,547),(330,722)],'Người duyệt / Từ chối\nHT / Hoàn quỹ đã trừ',(330,640))
box(d,330,1080,390,135,'Đã hủy','no')
arrow(d,[(230,547),(100,547),(100,1080),(135,1080)],'NV / Hủy đơn chưa duyệt\nHT / Hoàn quỹ đã trừ',(315,970))
box(d,1050,200,440,135,'Đề nghị sửa\nđang chờ xử lý','wait')
arrow(d,[(920,412),(920,267)],'NV / Gửi sửa\nHT / Điều chỉnh quỹ',(820,340))
arrow(d,[(1175,267),(1175,412)],'Người duyệt / Duyệt, từ chối\nHT / Cập nhật, khôi phục\nđơn và quỹ cũ',(1385,340))
box(d,1050,790,440,135,'Đề nghị hủy\nđang chờ xử lý','wait')
arrow(d,[(920,547),(920,722)],'NV / Gửi hủy\nHT / Chưa hoàn quỹ',(820,640))
arrow(d,[(1175,722),(1175,547)],'Người duyệt / Từ chối\nGiữ đơn và quỹ cũ',(1385,640))
arrow(d,[(830,790),(700,790),(700,1080),(525,1080)],'Người duyệt / Duyệt đủ cấp\nHT / Hoàn quỹ',(690,970))
box(d,1050,1120,440,135,'Bước trình ký\n(nếu không lương\ncó thỏa thuận)','task')
arrow(d,[(1270,480),(1530,480),(1530,1120),(1270,1120)],'HR SSC / Trình ký',(1350,965))
event(d,1050,1370,'End')
arrow(d,[(1050,1187),(1050,1350)],'HR SSC / Ký thành công',(1050,1280))
arrow(d,[(1270,480),(1570,480),(1570,1370),(1075,1370)],'HT / Hoàn tất\nkhi không cần ký',(1420,1260))
arrow(d,[(330,857),(330,905),(560,905),(560,1370),(1025,1370)])
arrow(d,[(330,1147),(330,1370),(1025,1370)])
text(d,790,53,'NV: Nhân viên     HT: Hệ thống     Mỗi liên kết thể hiện tác nhân / bước xử lý',small)
text(d,470,180,'NV / Sửa đơn chưa duyệt\nCập nhật ngay, vẫn Chờ duyệt',small)
arrow(d,[(380,412),(380,310),(600,310),(600,380),(490,380),(490,412)])
text(d,670,1200,'HT / Kết thúc xử lý\nđơn từ chối hoặc đã hủy',small)
im.save(WORK/'trang-thai-nghi-phep.png')

source=OUT/'Nghiệp vụ quản lý yêu cầu nghỉ phép.docx'
doc=Document(source)
body=doc.element.body
for e in list(body):
 if e.tag != qn('w:sectPr'): body.remove(e)
normal=doc.styles['Normal']; normal.font.name='Times New Roman'; normal.font.size=Pt(12)
normal.paragraph_format.space_after=Pt(6)
normal.paragraph_format.line_spacing=1.05
if 'Title' not in doc.styles:
 from docx.enum.style import WD_STYLE_TYPE
 doc.styles.add_style('Title',WD_STYLE_TYPE.PARAGRAPH)
ts=doc.styles['Title']; ts.font.name='Times New Roman'; ts.font.size=Pt(18); ts.font.bold=True; ts.font.color.rgb=RGBColor(0,0,0)
for n in ['Heading 1','Heading 2']:
 if n not in doc.styles:
  from docx.enum.style import WD_STYLE_TYPE
  doc.styles.add_style(n,WD_STYLE_TYPE.PARAGRAPH)
 st=doc.styles[n]; st.font.name='Times New Roman'; st.font.size=Pt(13); st.font.bold=True; st.font.color.rgb=RGBColor(0,0,0); st.paragraph_format.space_before=Pt(8); st.paragraph_format.space_after=Pt(6)
def p(s): return doc.add_paragraph(s)
def head(s): return doc.add_paragraph(s,'Heading 2')
def picture(path):
 p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER; p.paragraph_format.space_after=Pt(3); p.add_run().add_picture(str(path),width=Inches(6.45))
doc.add_paragraph('Nghiệp vụ đăng ký nghỉ phép trên Happy Connect','Title')
p('Báo cáo sơ bộ ngày 13/10/2026')
head('I. Mục đích')
p('Mô tả tạo mới, phê duyệt, sửa và hủy yêu cầu nghỉ phép trên Happy Connect; bổ sung hình thức nghỉ không lương và cập nhật hạn mức nghỉ cơ bản.')
p('Giới hạn thay đổi: giữ nguyên UI/UX, layout, spacing, màu sắc, typography, component, route và các màn hình khác; chỉ sửa thành phần cần thiết, tái sử dụng popup và biểu mẫu hiện có. Không sửa Web HRM hoặc gây ảnh hưởng qua dữ liệu/cấu hình dùng chung.')
head('II. Workflow')
picture(WORK/'workflow-nghi-phep.png')
p('Nghỉ phép, nghỉ dưỡng hàng năm và nghỉ việc riêng có hưởng lương: QLTT duyệt. Nghỉ không lương: QLTT → Trưởng phòng TCLĐ. Loại có thỏa thuận chỉ hoàn tất sau khi trình ký thành công; không thỏa thuận hoàn tất sau khi duyệt đủ cấp.')
doc.add_page_break()
head('III. Biểu đồ trạng thái')
picture(WORK/'trang-thai-nghi-phep.png')
p('Các ô đề nghị sửa/hủy và bước trình ký mô tả nghiệp vụ, không mặc định là tên trạng thái UI. End là kết thúc lần xử lý hiện tại; đơn đã duyệt vẫn có thể được đề nghị sửa/hủy.')
p('Trừ, hoàn hoặc khôi phục quỹ chỉ áp dụng với loại nghỉ sử dụng quỹ tương ứng. Nghỉ không lương không trừ quỹ phép năm/nghỉ dưỡng.')
p('Phương thức tích hợp, tên trạng thái chờ trình ký và xử lý trình ký thất bại/bị từ chối:')
doc.add_page_break()
head('IV. Danh sách chức năng')
rows=[
('Giao diện','Đổi tên tab','Điều chỉnh','Đổi “Đơn của tôi” thành “Đăng ký”; giữ nguyên vị trí, kiểu hiển thị và chức năng.'),
('Đăng ký','Tạo yêu cầu nghỉ','Điều chỉnh','Giữ các trường hiện có. Lý do nghỉ và người tiếp nhận công việc bắt buộc. Khi chọn nghỉ không lương, bắt buộc chọn Có thỏa thuận / Không thỏa thuận; không chọn sẵn. Hồ sơ cũ không tự gán hình thức.'),
('Nghỉ không lương','Lưu và hiển thị hình thức','Bổ sung','Lưu hình thức trên hồ sơ; hiển thị trong vùng thông tin hiện có của danh sách, chi tiết, phê duyệt và chỉnh sửa. Đổi sang loại nghỉ khác thì ẩn và không áp dụng giá trị này. Không trừ quỹ phép năm hoặc nghỉ dưỡng.'),
('Phê duyệt','Xử lý theo loại nghỉ','Điều chỉnh','Duyệt tuần tự theo cấu hình DB và PL02; cho phép xử lý nhiều đơn. Một cấp từ chối thì kết thúc đơn, ghi lý do, người và thời gian xử lý. Không lương có thỏa thuận chỉ hoàn tất sau trình ký thành công.'),
('Quỹ nghỉ','Hạn mức và tạm tính','Điều chỉnh','Phép năm cơ bản tối đa 12 ngày/năm; mỗi đủ 5 năm thâm niên +1 ngày (10 năm +2). Nghỉ dưỡng 3 ngày/năm. Tính theo nửa ngày; loại trừ thứ Bảy, Chủ nhật và ngày lễ. Cập nhật dữ liệu và phép tính nhất quán, không ghi đè lịch sử hoặc đặt lại quỹ khả dụng.'),
('Điều chỉnh','Sửa yêu cầu','Giữ quy tắc đã chốt','Chưa duyệt: cập nhật ngay, tiếp tục Chờ duyệt. Đã duyệt: gửi đề nghị sửa, điều chỉnh quỹ áp dụng lúc gửi; cần duyệt lại. Từ chối đề nghị: khôi phục đơn và quỹ theo đơn cũ.'),
('Hủy','Hủy yêu cầu','Giữ quy tắc đã chốt','Chưa duyệt: hủy ngay, hoàn quỹ đã trừ. Đã duyệt: gửi đề nghị hủy, chỉ hoàn quỹ sau khi được duyệt. Từ chối đề nghị: giữ đơn và quỹ cũ. Nghỉ không lương không phát sinh trừ/hoàn quỹ phép năm hoặc nghỉ dưỡng.'),
('Cấu hình','Danh mục và luồng duyệt','Trong DB','Danh mục loại nghỉ, quy tắc quỹ và luồng duyệt cấu hình trong DB. Không bổ sung UI quản lý loại nghỉ. Ánh xạ nhãn Nghỉ việc riêng với loại Rv; xử lý sửa/hủy trong thời gian chờ trình ký: '),
]
t=doc.add_table(rows=1,cols=6); t.autofit=False
widths=[.35,.8,.85,.75,3.15,.55]
for col,w in zip(t.columns,widths): col.width=Inches(w)
headers=['STT','Tính năng','Chức năng','Yêu cầu','Lưu ý về nghiệp vụ','Mức độ ưu tiên']
for c,h,w in zip(t.rows[0].cells,headers,widths): c.text=h; c.width=Inches(w)
for idx,row in enumerate(rows,1):
 cells=t.add_row().cells
 for c,txt,w in zip(cells,[str(idx),*row,''],widths): c.text=txt; c.width=Inches(w)
for i,r in enumerate(t.rows):
 pr=r._tr.get_or_add_trPr(); el=OxmlElement('w:cantSplit'); pr.append(el)
 if i==0: pr.append(OxmlElement('w:tblHeader'))
 for j,c in enumerate(r.cells):
  c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
  cp=c._tc.get_or_add_tcPr(); border=OxmlElement('w:tcBorders')
  for side in ['top','left','bottom','right']:
   e=OxmlElement('w:'+side); e.set(qn('w:val'),'single'); e.set(qn('w:sz'),'4'); e.set(qn('w:color'),'D9D9D9'); border.append(e)
  cp.append(border)
  mar=OxmlElement('w:tcMar')
  for side in ['top','left','bottom','right']:
   e=OxmlElement('w:'+side); e.set(qn('w:w'),'75'); e.set(qn('w:type'),'dxa'); mar.append(e)
  cp.append(mar)
  if i==0:
   sh=OxmlElement('w:shd'); sh.set(qn('w:fill'),'E8EEF5'); cp.append(sh)
  for pp in c.paragraphs:
   pp.paragraph_format.space_after=Pt(2); pp.paragraph_format.line_spacing=1.0
   if j in [0,5]: pp.alignment=WD_ALIGN_PARAGRAPH.CENTER
   for rr in pp.runs: rr.font.size=Pt(10); rr.font.bold=(i==0)
p('Căn cứ: prototype Happy Connect; PL01 Các loại ngày công; PL02 Luồng phê duyệt; QT.00.TCNL.20 lần 07; các quy tắc được xác nhận trong trao đổi. Mức độ ưu tiên và nội dung chưa chốt để trống.')
doc.core_properties.title='Nghiệp vụ đăng ký nghỉ phép trên Happy Connect'
doc.core_properties.author=''
path=OUT/'Báo cáo sơ bộ nghỉ phép Happy Connect.docx'; doc.save(path)
print(path)
