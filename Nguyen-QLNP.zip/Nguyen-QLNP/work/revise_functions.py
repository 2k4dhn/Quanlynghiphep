from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from copy import deepcopy
from lxml import etree as E

path=Path('outputs/Báo cáo sơ bộ nghỉ phép Happy Connect.docx')
with ZipFile(path) as z: parts={n:z.read(n) for n in z.namelist()}
W='http://schemas.openxmlformats.org/wordprocessingml/2006/main'; ns={'w':W}
doc=E.fromstring(parts['word/document.xml']); body=doc.find('w:body',ns); table=body.find('w:tbl',ns)
pattern=deepcopy(table.findall('w:tr',ns)[1])
rows=[
('Quản lý yêu cầu','Xem danh sách yêu cầu nghỉ phép','Hiển thị các đơn của nhân viên.','Đổi tên tab “Đơn của tôi” thành “Đăng ký”; giữ nguyên vị trí, kiểu hiển thị và chức năng. Danh sách thể hiện loại nghỉ, thời gian, số ngày, ngày gửi, trạng thái và người xử lý.'),
('Tra cứu yêu cầu','Tìm kiếm và lọc yêu cầu','Tra cứu theo tiêu chí hiện có.','Tìm theo mã đơn, loại nghỉ, lý do; lọc loại nghỉ, trạng thái, người duyệt, khoảng thời gian nghỉ và ngày gửi. Có áp dụng và đặt lại bộ lọc.'),
('Đăng ký nghỉ','Tạo yêu cầu nghỉ phép','Nhập thông tin và gửi yêu cầu.','Giữ các trường hiện có; lý do nghỉ và người tiếp nhận công việc bắt buộc. Nghỉ không lương: bắt buộc chọn Có thỏa thuận / Không thỏa thuận, không chọn sẵn. Lưu lựa chọn; không tự gán cho hồ sơ cũ. Đổi sang loại khác thì ẩn và không áp dụng giá trị này. Hồ sơ đính kèm theo PL02.'),
('Quản lý yêu cầu','Xem chi tiết yêu cầu','Hiển thị thông tin đơn và kết quả xử lý.','Gồm mã đơn, người gửi, loại/hình thức nghỉ, thời gian, số ngày, lý do, nơi nghỉ, người tiếp nhận, tệp đính kèm, thông tin duyệt và lý do từ chối khi có. Dùng vùng thông tin hiện có.'),
('Quỹ nghỉ','Xem quỹ nghỉ và số ngày tạm tính','Hiển thị quỹ khả dụng, số ngày nghỉ và dự kiến còn lại.','Phép năm cơ bản tối đa 12 ngày/năm; mỗi đủ 5 năm thâm niên +1 ngày. Nghỉ dưỡng 3 ngày/năm. Tính theo nửa ngày, loại trừ thứ Bảy, Chủ nhật, ngày lễ. Trừ quỹ áp dụng khi gửi. Nghỉ không lương không trừ quỹ phép năm/nghỉ dưỡng. Không đặt lại quỹ hoặc ghi đè lịch sử.'),
('Điều chỉnh yêu cầu','Chỉnh sửa và gửi đề nghị điều chỉnh','Sửa thông tin; lý do điều chỉnh bắt buộc.','Chưa duyệt: cập nhật ngay, tiếp tục Chờ duyệt. Đã duyệt: gửi đề nghị sửa, điều chỉnh quỹ áp dụng lúc gửi và duyệt lại. Bị từ chối: khôi phục đơn và quỹ theo đơn cũ. Form chỉnh sửa hiển thị lại hình thức nghỉ không lương đã lưu.'),
('Hủy yêu cầu','Hủy đơn và gửi đề nghị hủy','Nhập lý do và xác nhận hủy.','Chưa duyệt: hủy ngay, hoàn quỹ đã trừ. Đã duyệt: gửi đề nghị hủy; chỉ hoàn quỹ sau chấp thuận. Từ chối đề nghị: giữ đơn và quỹ cũ. Nghỉ không lương không phát sinh trừ/hoàn quỹ phép năm hoặc nghỉ dưỡng.'),
('Phê duyệt','Xem danh sách yêu cầu cần phê duyệt','Hiển thị đơn thuộc phạm vi xử lý của người duyệt.','Có các nhóm Đơn nghỉ phép, Đề nghị hủy, Đề nghị điều chỉnh. Hiển thị trạng thái, người gửi và thông tin đơn; bổ sung hình thức nghỉ không lương trong vùng thông tin hiện có.'),
('Phê duyệt','Duyệt hoặc từ chối yêu cầu','Xem chi tiết và xác nhận kết quả xử lý.','Duyệt tuần tự theo cấu hình DB và PL02. Từ chối bắt buộc lý do; một cấp từ chối thì đơn kết thúc, hoàn quỹ đã trừ. Ghi người và thời gian xử lý. Nghỉ không lương có thỏa thuận chỉ hoàn tất sau trình ký thành công.'),
('Phê duyệt','Duyệt hoặc từ chối nhiều yêu cầu','Chọn nhiều đơn và xác nhận xử lý.','Có chọn từng đơn, chọn tất cả, bỏ chọn và số lượng đã chọn. Tái sử dụng popup hiện có; không bỏ qua các cấp duyệt. Quy tắc khi một đơn được chọn không hợp lệ: '),
('Phê duyệt','Phê duyệt đề nghị điều chỉnh hoặc hủy','Duyệt hoặc từ chối đề nghị của đơn đã duyệt.','Cấp có thẩm quyền duyệt loại nghỉ nào tiếp nhận điều chỉnh loại đó. Sửa được chấp thuận: cập nhật đơn; bị từ chối: khôi phục đơn/quỹ cũ. Hủy được chấp thuận: Đã hủy, hoàn quỹ; bị từ chối: giữ đơn/quỹ cũ.'),
('Theo dõi xử lý','Xem lịch sử xử lý','Hiển thị diễn biến xử lý của đơn.','Ghi nhận thao tác, người thực hiện, thời gian, kết quả và lý do tương ứng để theo dõi các lần gửi, duyệt, từ chối, sửa và hủy.'),
]
for tr in table.findall('w:tr',ns)[1:]: table.remove(tr)
for i,row in enumerate(rows,1):
 tr=deepcopy(pattern)
 for c,s in zip(tr.findall('w:tc',ns),[str(i),*row,'']):
  old=c.find('w:p',ns); p=deepcopy(old)
  for child in list(p):
   if child.tag!='{'+W+'}pPr': p.remove(child)
  oldrun=old.find('w:r',ns); run=E.SubElement(p,'{'+W+'}r')
  if oldrun is not None and oldrun.find('w:rPr',ns) is not None: run.append(deepcopy(oldrun.find('w:rPr',ns)))
  text=E.SubElement(run,'{'+W+'}t'); text.text=s
  for child in list(c):
   if child.tag!='{'+W+'}tcPr': c.remove(child)
  c.append(p)
 table.append(tr)

notes=[
'Quy tắc nghiệp vụ: danh mục loại nghỉ, quy tắc quỹ và luồng duyệt cấu hình trong DB; không bổ sung UI quản lý loại nghỉ. Không lương: QLTT → Trưởng phòng TCLĐ; có thỏa thuận cần HR SSC trình ký thành công mới hoàn tất. Phương thức tích hợp chưa chốt.',
'Nội dung chưa chốt: ánh xạ nhãn Nghỉ việc riêng với Rv; xử lý sửa/hủy trong thời gian chờ trình ký; tên trạng thái và xử lý trình ký thất bại/bị từ chối:',
]
pos=list(body).index(table)+1
template=next(p for p in body.findall('w:p',ns) if 'Giới hạn thay đổi:' in ''.join(p.itertext()))
for s in notes:
 p=deepcopy(template)
 for c in list(p):
  if c.tag!='{'+W+'}pPr': p.remove(c)
 r=E.SubElement(p,'{'+W+'}r'); t=E.SubElement(r,'{'+W+'}t'); t.text=s
 body.insert(pos,p); pos+=1
parts['word/document.xml']=E.tostring(doc,xml_declaration=True,encoding='UTF-8',standalone=True)
with ZipFile(path,'w',ZIP_DEFLATED) as z:
 for n,b in parts.items(): z.writestr(n,b)
print(path.resolve())
