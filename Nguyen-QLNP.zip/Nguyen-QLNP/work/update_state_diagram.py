from pathlib import Path
from docx import Document
from docx.shared import Inches,Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH,WD_BREAK
from zipfile import ZipFile
from hashlib import sha256

# Reuse only the vector drawing helpers, without rebuilding existing workflows.
helper=Path('work/draw_swimlanes.py').read_text(encoding='utf8')
exec(helper[:helper.index("c=Chart('Quy trình tạo mới")])
c=Chart('Biểu đồ trạng thái đơn đăng ký nghỉ phép',['Đơn đăng ký mới — tác nhân / bước xử lý trên đường chuyển'],height=1450)
c.arrow([(193,520),(435,520)],'NV / Gửi đơn\nHT / Trừ quỹ áp dụng',(305,385))
c.arrow([(865,520),(1285,520)],'Người duyệt / Duyệt đủ cấp',(1075,390))
c.arrow([(600,450),(600,315),(820,315),(820,450)],'NV / Sửa hợp lệ\nHT / Cập nhật quỹ, duyệt lại từ cấp 1',(785,285))
c.arrow([(650,590),(650,780)],'Người duyệt / Từ chối\nHT / Hoàn phần quỹ còn hạn',(650,680))
c.arrow([(500,590),(350,590),(350,1170),(435,1170)],'NV / Hủy khi chưa duyệt hoàn tất\nhoặc HT / Tự hủy qua 31/03 nếu dùng phép cũ\nHT / Hoàn phần quỹ còn hạn',(675,1020))
c.arrow([(1715,520),(2257,520)],'HT / Hoàn tất\nkhi không cần trình ký',(1990,385))
c.arrow([(1500,590),(1500,965)],'HR SSC / Trình ký\nNghỉ không lương có thỏa thuận',(1500,760))
c.arrow([(1500,1135),(2300,1135),(2300,563)],'HR SSC / Ký thành công',(2080,1060))
c.arrow([(865,850),(1100,850),(1100,1127)])
c.arrow([(865,1170),(1057,1170)],'HT / Kết thúc xử lý',(970,1260))
c.event(160,520); c.event(2300,520,True); c.event(1100,1170,True)
c.box(650,520,'Chờ duyệt',w=430)
c.box(1500,520,'Đã duyệt',w=430)
c.box(650,850,'Từ chối',w=430)
c.box(650,1170,'Đã hủy',w=430)
c.rect(1250,965,1750,1135,'#f5f7fa','#799bc8',3,20)
c.txt(1500,1050,'Bước trình ký',34)
c.txt(1880,1300,'Tên trạng thái chờ ký và xử lý\nký thất bại / bị từ chối: ',29)
c.txt(1300,1385,'NV: Nhân viên. HT: Hệ thống. End: kết thúc lần xử lý; đơn đã duyệt có thể phát sinh đề nghị mới.',29)
c.save('Biểu đồ trạng thái đơn nghỉ phép cập nhật')

c=Chart('Biểu đồ trạng thái đề nghị điều chỉnh hoặc hủy',['Đề nghị gắn với đơn gốc đã duyệt — dùng chung trạng thái Chờ duyệt'],height=1500)
c.arrow([(193,520),(535,520)],'NV / Gửi đề nghị\nHT / Sửa: điều chỉnh quỹ; hủy: chưa hoàn',(365,385))
c.arrow([(965,520),(1635,520)],'Người duyệt / Duyệt đủ cấp',(1300,390))
c.arrow([(700,450),(700,315),(920,315),(920,450)],'Người duyệt / Duyệt một cấp\nHT / Chuyển cấp tiếp theo',(920,285))
c.arrow([(750,590),(750,780)],'Người duyệt / Từ chối đề nghị',(750,680))
c.arrow([(600,590),(420,590),(420,1200),(535,1200)],'HT / Qua 31/03, đề nghị liên quan phép cũ\nTự hủy toàn bộ đề nghị; giữ đơn gốc',(750,1045))
c.arrow([(2065,520),(2317,520)],'HT / Kết thúc',(2190,400))
c.arrow([(965,850),(1120,850),(1120,1157)])
c.arrow([(965,1200),(1077,1200)],'HT / Kết thúc',(1040,1310))
c.event(160,520); c.event(2360,520,True); c.event(1120,1200,True)
c.box(750,520,'Chờ duyệt\nLoại: Điều chỉnh / Hủy',w=430,h=140)
c.box(1850,520,'Đã duyệt\n(kết quả đề nghị)',w=430)
c.box(750,850,'Từ chối\n(đề nghị)',w=430)
c.box(750,1200,'Đã hủy\n(đề nghị)',w=430)
c.txt(1850,730,'HT / Điều chỉnh: cập nhật đơn gốc\nHT / Hủy: đơn gốc chuyển Đã hủy,\nhoàn phần quỹ còn hạn',29)
c.txt(1730,950,'HT / Giữ bản đơn gốc đã duyệt\nNếu sửa: khôi phục quỹ theo đơn cũ\nKhông đưa phép hết hạn vào quỹ khả dụng',29)
c.txt(1800,1240,'Lý do tự hủy: Phép cũ hết hạn\nNếu sửa: xử lý khôi phục quỹ theo nguồn\nNếu hủy: giữ nguyên đơn và quỹ cũ',29)
c.txt(1300,1430,'Không được gửi đề nghị khi đã chốt công hoặc đơn đã đến bước trình ký.',29)
c.save('Biểu đồ trạng thái đề nghị sửa hủy cập nhật')

path=OUT/'Báo cáo sơ bộ nghỉ phép Happy Connect.docx'
doc=Document(path); pars=doc.paragraphs
head=next(p for p in pars if p.text=='III. Biểu đồ trạng thái')
idx=pars.index(head)
oldimage=next(p for p in pars[idx+1:] if p._p.xpath('.//w:drawing'))
tablexml=doc.tables[0]._tbl.xml
workflow_ids=[s._inline.graphic.graphicData.pic.blipFill.blip.embed for s in list(doc.inline_shapes)[:2]]
def after(anchor,text='',page=False):
 p=doc.add_paragraph(text); anchor._p.addnext(p._p)
 if page: p.add_run().add_break(WD_BREAK.PAGE)
 return p
cap=after(head,'1. Trạng thái đơn đăng ký mới'); cap.runs[0].bold=True; cap.paragraph_format.keep_with_next=True
oldimage.clear(); oldimage.alignment=WD_ALIGN_PARAGRAPH.CENTER
image1=OUT/'Biểu đồ trạng thái đơn nghỉ phép cập nhật.png'; image2=OUT/'Biểu đồ trạng thái đề nghị sửa hủy cập nhật.png'
oldimage.add_run().add_picture(str(image1),width=Inches(6.45))
br=after(oldimage,page=True)
cap2=after(br,'2. Trạng thái đề nghị sửa hoặc hủy đơn đã duyệt'); cap2.runs[0].bold=True; cap2.paragraph_format.keep_with_next=True
p=after(cap2); p.alignment=WD_ALIGN_PARAGRAPH.CENTER; p.add_run().add_picture(str(image2),width=Inches(6.45))
for pp in doc.paragraphs:
 if pp.text.startswith('Các ô đề nghị sửa/hủy'):
  pp.text='Đơn đăng ký, đề nghị điều chỉnh và đề nghị hủy dùng chung các trạng thái Chờ duyệt, Đã duyệt, Từ chối, Đã hủy; phân biệt bằng loại yêu cầu. Đề nghị gắn với bản đơn gốc đã duyệt. End là kết thúc lần xử lý hiện tại.'
 elif pp.text.startswith('Trừ, hoàn hoặc khôi phục quỹ chỉ'):
  pp.text='Sửa đơn chưa duyệt hoàn tất: kiểm tra quỹ và trùng lịch; hợp lệ thì cập nhật ngay và duyệt lại từ cấp 1. Không hợp lệ: giữ nguyên đơn, quỹ và bước duyệt cũ. Khóa sửa/hủy sau chốt công hoặc khi đến bước trình ký.'
 elif pp.text.startswith('Nội dung chưa chốt: ánh xạ'):
  pp.text='Nội dung chưa chốt: ánh xạ nhãn Nghỉ việc riêng với Rv; tên trạng thái chờ trình ký và xử lý trình ký thất bại/bị từ chối:'
assert doc.tables[0]._tbl.xml==tablexml
doc.save(path)
d=Document(path); assert len(d.inline_shapes)==4
assert d.tables[0]._tbl.xml==tablexml
assert [s._inline.graphic.graphicData.pic.blipFill.blip.embed for s in list(d.inline_shapes)[:2]]==workflow_ids
with ZipFile(path) as z:
 assert z.testzip() is None
 hashes={sha256(z.read(n)).hexdigest() for n in z.namelist() if n.startswith('word/media/')}
 assert all(sha256(p.read_bytes()).hexdigest() in hashes for p in [image1,image2])
print('Updated state diagrams embedded; two workflows and seven-column function table preserved.')
