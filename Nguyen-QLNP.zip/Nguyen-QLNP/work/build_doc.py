from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from copy import deepcopy
from lxml import etree as E
import hashlib

root=Path.cwd()
src=Path(r'C:\Users\ADMIN\AppData\Local\Temp\codex-file-preview-rLmqQu\Nghiệp vụ quản lý yêu cầu nhập kho.docx')
out=root/'outputs'/'Nghiệp vụ quản lý yêu cầu nghỉ phép.docx'
W='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
ns={'w':W}
def tag(s): return '{'+W+'}'+s
def sub(p,s,**attrs):
    e=E.SubElement(p,tag(s))
    for k,v in attrs.items(): e.set(tag(k),str(v))
    return e
with ZipFile(src) as z:
    parts={n:z.read(n) for n in z.namelist()}
doc=E.fromstring(parts['word/document.xml'])
body=doc.find('w:body',ns)
sect=deepcopy(body.find('w:sectPr',ns))
source_table=body.find('w:tbl',ns)
table=deepcopy(source_table)
header=deepcopy(table.find('w:tr',ns))
row_pattern=deepcopy(table.findall('w:tr',ns)[1])
for c in list(body): body.remove(c)

def para(parent,text='',size=24,bold=False,after=100,before=0,keep=False):
    p=sub(parent,'p'); pp=sub(p,'pPr')
    sub(pp,'spacing',before=before,after=after,line=260,lineRule='auto')
    if keep: sub(pp,'keepNext')
    r=sub(p,'r'); rp=sub(r,'rPr')
    sub(rp,'rFonts',ascii='Times New Roman',hAnsi='Times New Roman',eastAsia='Times New Roman')
    sub(rp,'sz',val=size); sub(rp,'color',val='000000')
    if bold: sub(rp,'b')
    t=sub(r,'t'); t.text=text
    return p

title=para(body,'Nghiệp vụ quản lý yêu cầu nghỉ phép',size=36,bold=True,after=160,keep=True)
sub(title.find('w:pPr',ns),'pStyle',val='Heading1')
para(body,'I. Mục đích',bold=True,before=100,keep=True)
para(body,'Quản lý việc đăng ký, theo dõi và phê duyệt yêu cầu nghỉ phép trên Happy Connect và Web HRM. Danh mục loại nghỉ, quy tắc trừ phép và luồng duyệt được cấu hình trong DB; loại bỏ chức năng quản lý loại nghỉ khỏi UI.')
para(body,'Căn cứ nghiệp vụ: PL01 Các loại ngày công; PL02 Luồng phê duyệt; QT.00.TCNL.20 lần 07, hiệu lực 01/07/2023. Phạm vi sơ bộ gồm các nhóm nghỉ trên prototype.',size=22)
para(body,'II. Workflow',bold=True,before=100,keep=True)
para(body,'1. Nhân viên chọn loại nghỉ, nhập thời gian và thông tin yêu cầu; xem số ngày tạm tính, quỹ khả dụng và luồng duyệt; gửi yêu cầu.')
para(body,'2. Trừ quỹ áp dụng khi gửi đơn. Duyệt tuần tự theo loại công nghỉ và PL02, cấu hình trong DB; có thể duyệt nhiều đơn cùng lúc. Một cấp từ chối thì đơn kết thúc và hoàn quỹ đã trừ.')
para(body,'3. Đơn chưa duyệt: sửa/hủy được cập nhật ngay; hủy thì hoàn quỹ đã trừ. Đơn đã duyệt: sửa/hủy phải duyệt lại; quỹ điều chỉnh ngay khi gửi sửa, chỉ hoàn khi đề nghị hủy được duyệt. Từ chối đề nghị thì đơn trở về trạng thái cũ; từ chối sửa thì khôi phục quỹ theo đơn cũ.')
para(body,'4. Nghỉ có kế hoạch phải được duyệt trước khi nghỉ. Nghỉ đột xuất: báo QLTT để xác nhận, hoàn thiện đăng ký trong ngày làm việc đầu tiên sau kỳ nghỉ; TCLĐ hỗ trợ khi cần. Đơn được duyệt được ghi nhận công theo quy trình.')
para(body,'5. Nếu loại nghỉ cần ký đơn, thực hiện bước HR SSC trình ký theo PL02. Người có thẩm quyền duyệt loại nghỉ nào tiếp nhận điều chỉnh loại đó. Phạm vi tích hợp S4/V-Office và đồng bộ chấm công:')
para(body,'III. Biểu đồ trạng thái',bold=True,before=100,keep=True)
para(body,'Đơn nghỉ phép',bold=True,after=40)
para(body,'Gửi yêu cầu → Chờ duyệt → Đã duyệt / Từ chối')
para(body,'Chờ duyệt → Đã hủy: nhân viên hủy, cập nhật ngay và hoàn quỹ đã trừ. Một cấp duyệt từ chối → Từ chối và kết thúc.')
para(body,'Đề nghị hủy',bold=True,after=40)
para(body,'Chờ duyệt hủy → Đã chấp thuận / Từ chối đề nghị')
para(body,'Đơn đã duyệt: chấp thuận hủy → Đã hủy và hoàn quỹ đã trừ; từ chối đề nghị → trạng thái cũ của đơn.')
para(body,'Đề nghị điều chỉnh',bold=True,after=40)
para(body,'Đơn đã duyệt phải duyệt lại khi sửa; từ chối đề nghị → đơn trở về trạng thái cũ và khôi phục quỹ theo đơn cũ. Tên trạng thái của đề nghị điều chỉnh:')
pb=sub(body,'p'); rr=sub(pb,'r'); sub(rr,'br',type='page')
para(body,'IV. Danh sách chức năng',bold=True,after=140,keep=True)

rows=[
('Đăng ký nghỉ phép','Thêm yêu cầu nghỉ phép','', 'Loại nghỉ; thời gian từ/đến; lý do nghỉ*; nơi nghỉ; người tiếp nhận công việc*; tệp. * Bắt buộc trên prototype. Chọn nghỉ không lương thì có 2 lựa chọn: Có thỏa thuận / Không thỏa thuận. Hồ sơ theo PL02. Nghỉ có kế hoạch phải duyệt trước; nghỉ đột xuất hoàn thiện đăng ký ngày đầu trở lại.'),
('Theo dõi yêu cầu','Xem danh sách đơn của tôi','', 'Hiển thị loại nghỉ, thời gian, tổng ngày, ngày gửi, trạng thái, người duyệt/xử lý và lý do nghỉ.'),
('Tra cứu yêu cầu','Tìm kiếm và lọc','', 'Mobile: tìm theo mã đơn, loại nghỉ, lý do; lọc loại nghỉ, trạng thái, người duyệt, khoảng nghỉ và ngày gửi. Web: thêm đơn vị, người xử lý, ngày xử lý; có xóa bộ lọc.'),
('Theo dõi yêu cầu','Xem chi tiết và lịch sử xử lý','', 'Xem thông tin nhân sự, nội dung đơn, quỹ phép, thông tin duyệt và lịch sử. Hiển thị lý do từ chối khi có.'),
('Điều chỉnh yêu cầu','Chỉnh sửa và đề nghị điều chỉnh','', 'Chưa duyệt: cập nhật ngay. Đã duyệt: duyệt lại, điều chỉnh quỹ lúc gửi; từ chối đề nghị thì trở về trạng thái cũ và khôi phục quỹ theo đơn cũ. Lý do điều chỉnh bắt buộc.'),
('Hủy yêu cầu','Gửi yêu cầu hủy','', 'Lý do hủy bắt buộc. Chưa duyệt: hủy ngay và hoàn quỹ đã trừ. Đã duyệt: cần duyệt hủy, chỉ hoàn quỹ sau chấp thuận; từ chối đề nghị thì trở về trạng thái cũ.'),
('Phê duyệt','Duyệt hoặc từ chối đơn','', 'Duyệt tuần tự từng cấp; một cấp từ chối thì đơn kết thúc, hoàn phép. Lý do từ chối bắt buộc. Web chỉ chọn đơn chờ duyệt được giao trên trang hiện tại.'),
('Phê duyệt','Duyệt hoặc từ chối nhiều đơn','', 'Chọn từng đơn/chọn tất cả; hiển thị số đơn chọn; duyệt, từ chối hoặc bỏ chọn. Quy tắc xử lý khi một đơn trong nhóm không hợp lệ: '),
('Phê duyệt','Xử lý đề nghị hủy và điều chỉnh','', 'Các nhóm Đơn nghỉ phép, Đề nghị hủy, Đề nghị điều chỉnh. Theo quy trình, cấp có thẩm quyền duyệt loại nghỉ nào thì tiếp nhận và duyệt/từ chối điều chỉnh loại đó.'),
('Quỹ phép','Xem quỹ và số ngày tạm tính','', 'Đơn vị nửa ngày, loại trừ thứ Bảy, Chủ nhật, ngày lễ. Phép năm 12 ngày; mỗi 5 năm thâm niên +1 (10 năm +2). PL01: phép theo tháng làm việc thực tế. Nghỉ dưỡng hàng năm tối đa 3 ngày làm việc. Cách phân bổ/làm tròn: '),
('Quản lý yêu cầu','Xuất file','', 'Có nút Xuất file trên Web. Định dạng, phạm vi dữ liệu và các cột xuất: '),
('Giao diện','Bỏ quản lý các loại nghỉ','Loại bỏ khỏi UI', 'Bỏ nút và màn hình quản lý loại nghỉ. Vẫn giữ việc chọn loại nghỉ khi lập đơn và lọc danh sách; danh mục lấy từ DB.'),
('Cấu hình nghiệp vụ','Danh mục và điều kiện loại nghỉ','Cấu hình trong DB', 'PL01: P nghỉ phép (còn phép; không chấm cho thử việc/tập nghề); DL hàng năm (không áp dụng thử việc, tập nghề, chờ thôi việc, tạm hoãn HĐLĐ). Rv: bản thân kết hôn hoặc bố/mẹ hai bên, vợ/chồng, con mất: tối đa 3 ngày; con kết hôn: 1 ngày. Ro: UI có lựa chọn Có thỏa thuận / Không thỏa thuận. Ánh xạ nhãn Nghỉ việc riêng với Rv: '),
('Cấu hình nghiệp vụ','Luồng duyệt theo loại công nghỉ','Cấu hình trong DB', 'PL02: P, DL hàng năm, Rv → QLTT; Ro không/có thỏa thuận → QLTT → Trưởng phòng TCLĐ. Nhân sự Dự án nước ngoài thuộc các Tổng Công ty: đầu mối duyệt là Trưởng phòng TCLĐ Tổng Công ty. Không gộp DL với dưỡng sức BHXH (DS).'),
('Phối hợp nghiệp vụ','Trình ký khi cần và ghi nhận công','', 'Ro có thỏa thuận: HR SSC trình ký S4/V-Office sau duyệt. Phép năm thông thường không yêu cầu ký; trường hợp chứng từ thanh toán tàu xe dùng BM06 theo quy trình. Phạm vi tích hợp: '),
]
for tr in table.findall('w:tr',ns): table.remove(tr)
table.append(header)
hp=header.find('w:trPr',ns)
if hp is None: hp=sub(header,'trPr')
sub(hp,'tblHeader')
headers=['STT','Tính năng','Chức năng','Yêu cầu','Lưu ý về nghiệp vụ','Mức độ ưu tiên']
def fillcell(cell,text,bold=False):
    cp=cell.find('w:tcPr',ns)
    for child in list(cell):
        if child is not cp: cell.remove(child)
    if cp is None: cp=sub(cell,'tcPr')
    for s in cp.findall('w:vAlign',ns): cp.remove(s)
    sub(cp,'vAlign',val='center')
    para(cell,text,size=22,bold=bold,after=60,before=60)
for c,h in zip(header.findall('w:tc',ns),headers): fillcell(c,h,True)
for i,row in enumerate(rows,1):
    tr=deepcopy(row_pattern)
    pr=tr.find('w:trPr',ns)
    if pr is not None:
        for child in list(pr): pr.remove(child)
    else: pr=sub(tr,'trPr')
    sub(pr,'cantSplit')
    for c,t in zip(tr.findall('w:tc',ns),[str(i),*row,'']): fillcell(c,t)
    table.append(tr)
body.append(table); body.append(sect)
parts['word/document.xml']=E.tostring(doc,xml_declaration=True,encoding='UTF-8',standalone=True)
with ZipFile(out,'w',ZIP_DEFLATED) as z:
    for name,data in parts.items(): z.writestr(name,data)
contract=f'''Reference: {src}\nSHA256: {hashlib.sha256(src.read_bytes()).hexdigest()}\nPage system: Letter portrait; margins 2.54 cm. Retain source section properties.\nTypography: Times New Roman 12 pt body; source Heading1 title adapted to 18 pt black; table 11 pt.\nStructure: I–IV retained; workflows and state diagrams are editable text. Function table retains source column widths and borders; repeat header; no split rows.\nSlots: source title, purpose, workflow images, state image and function rows replaced. All unknown rules and priorities blank. 13 concise function rows.\nPackage: only word/document.xml changed; all other parts byte-for-byte retained. Original images retained in package but unused in body.\nIntentional changes: explicit page break before IV for legibility; concise content.\nRender evidence: renderer attempted, blocked because bundled soffice.exe unavailable. No visual QA claim.\n'''
(root/'work'/'artifact.md').write_text(contract,encoding='utf8')
print(out)
