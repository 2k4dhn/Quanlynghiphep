from pathlib import Path
from docx import Document
import struct
base=Path(r'C:\Users\ADMIN\OneDrive\Desktop\Nguyen_VTIT\2023.06 Quy trinh cham cong - chot ky\2023.06 Quy trinh cham cong - chot ky')
for name in ['PL01 Cac loai ngay cong.docx','PL02 Luong phe duyet.docx']:
 d=Document(base/name)
 text='\n'.join(p.text for p in d.paragraphs)+'\n'+'\n'.join('\n'.join(' | '.join(dict.fromkeys(c.text for c in r.cells)) for r in t.rows) for t in d.tables)
 Path('work',name+'.txt').write_text(text,encoding='utf8')
b=(base/'Quy trinh cham cong toan TD.doc').read_bytes()
u16=lambda x,o:struct.unpack_from('<H',x,o)[0]
u32=lambda x,o:struct.unpack_from('<I',x,o)[0]
ss=1<<u16(b,30)
sector=lambda n:b[(n+1)*ss:(n+2)*ss]
fatids=list(struct.unpack_from('<109I',b,76))
dif=u32(b,68)
for _ in range(u32(b,72)):
 z=sector(dif); ids=struct.unpack('<'+'I'*(ss//4),z); fatids.extend(ids[:-1]); dif=ids[-1]
fat=[]
for fid in fatids:
 if fid<0xfffffffa: fat.extend(struct.unpack('<'+'I'*(ss//4),sector(fid)))
def chain(start,arr= None,get= None):
 arr=fat if arr is None else arr; get=sector if get is None else get
 buf=[]; seen=set()
 while start<0xfffffffa:
  assert start not in seen; seen.add(start); buf.append(get(start)); start=arr[start]
 return b''.join(buf)
directory=chain(u32(b,48)); entries={}
for i in range(0,len(directory),128):
 e=directory[i:i+128]; n=u16(e,64)
 if n: entries[e[:n-2].decode('utf-16le')]=(e[66],u32(e,116),struct.unpack_from('<Q',e,120)[0])
root=next(v for v in entries.values() if v[0]==5)
mini=chain(root[1])[:root[2]]
mf=chain(u32(b,60)); minifat=struct.unpack('<'+'I'*(len(mf)//4),mf)
def stream(name):
 _,start,size=entries[name]
 if size<u32(b,56): return chain(start,minifat,lambda n:mini[n*64:(n+1)*64])[:size]
 return chain(start)[:size]
word=stream('WordDocument'); table=stream('1Table' if u16(word,10)&0x200 else '0Table')
pos=32; csw=u16(word,pos); pos+=2+csw*2; cslw=u16(word,pos); pos+=2+cslw*4; count=u16(word,pos); pos+=2
fc,lcb=struct.unpack_from('<II',word,pos+33*8); clx=table[fc:fc+lcb]; k=0
while clx[k]==1: k+=3+u16(clx,k+1)
assert clx[k]==2
length=u32(clx,k+1); plc=clx[k+5:k+5+length]; n=(length-4)//12
cps=struct.unpack_from('<'+'I'*(n+1),plc); text=[]
for j in range(n):
 fc=u32(plc,4*(n+1)+8*j+2); compressed=bool(fc&0x40000000); off=fc&0x3fffffff; chars=cps[j+1]-cps[j]
 if compressed: text.append(word[off//2:off//2+chars].decode('cp1252',errors='replace'))
 else: text.append(word[off:off+chars*2].decode('utf-16le',errors='replace'))
out=''.join(text).replace('\r','\n').replace('\x07',' | ')
Path('work/main-process.txt').write_text(out,encoding='utf8')
print(out)
