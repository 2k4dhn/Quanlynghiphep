from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
from lxml import etree as E
from copy import deepcopy
from docx import Document
path=Path('outputs/Báo cáo sơ bộ nghỉ phép Happy Connect.docx')
with ZipFile(path) as z: parts={n:z.read(n) for n in z.namelist()}
W='http://schemas.openxmlformats.org/wordprocessingml/2006/main'; ns={'w':W}
def tag(x): return '{'+W+'}'+x
doc=E.fromstring(parts['word/document.xml']); body=doc.find('w:body',ns); table=body.find('w:tbl',ns)
rows=table.findall('w:tr',ns); assert len(rows[0].findall('w:tc',ns))==6
# Widths total 6.45 inches, retaining the original portrait geometry.
widths=[.3,.75,.75,.95,.7,2.5,.5]
grid=table.find('w:tblGrid',ns)
for c in list(grid): grid.remove(c)
for w in widths:
 e=E.SubElement(grid,tag('gridCol')); e.set(tag('w'),str(round(w*1440)))
both={2,4,5,8,9,10}
for i,r in enumerate(rows):
 cells=r.findall('w:tc',ns); added=deepcopy(cells[1]); oldp=added.find('w:p',ns)
 for child in list(oldp):
  if child.tag!=tag('pPr'): oldp.remove(child)
 rr=E.SubElement(oldp,tag('r')); rp=E.SubElement(rr,tag('rPr')); sz=E.SubElement(rp,tag('sz')); sz.set(tag('val'),'20')
 if i==0: E.SubElement(rp,tag('b'))
 txt='Nền tảng' if i==0 else ('Web và Happy Connect' if i in both else 'Happy Connect\nWeb: ')
 for j,line in enumerate(txt.split('\n')):
  if j: E.SubElement(rr,tag('br'))
  e=E.SubElement(rr,tag('t')); e.text=line
  e.set('{http://www.w3.org/XML/1998/namespace}space','preserve')
 r.insert(list(r).index(cells[1]),added)
 for c,w in zip(r.findall('w:tc',ns),widths):
  cp=c.find('w:tcPr',ns); cw=cp.find('w:tcW',ns)
  if cw is None: cw=E.SubElement(cp,tag('tcW'))
  cw.set(tag('w'),str(round(w*1440))); cw.set(tag('type'),'dxa')
note=E.Element(tag('p')); rr=E.SubElement(note,tag('r')); tt=E.SubElement(rr,tag('t'))
tt.text='Cột Nền tảng phân loại chức năng theo prototype. Phạm vi thay đổi của báo cáo vẫn chỉ là Happy Connect. Web: ô trống là nội dung chưa chốt; chức năng xem quỹ trên Web không bao gồm tạm tính khi tạo đơn.'
body.insert(list(body).index(table)+1,note)
parts['word/document.xml']=E.tostring(doc,xml_declaration=True,encoding='UTF-8',standalone=True)
with ZipFile(path,'w',ZIP_DEFLATED) as z:
 for n,b in parts.items(): z.writestr(n,b)
d=Document(path); assert len(d.tables[0].columns)==7; assert len(d.tables[0].rows)==13; assert len(d.inline_shapes)==2
assert all(len(r.cells)==7 for r in d.tables[0].rows)
assert d.tables[0].cell(0,1).text=='Nền tảng'
assert ZipFile(path).testzip() is None
print('Verified: 7 columns; 12 functions; 2 diagrams preserved.')
print(path.resolve())
