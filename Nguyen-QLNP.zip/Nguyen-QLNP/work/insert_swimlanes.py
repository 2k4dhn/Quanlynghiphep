from pathlib import Path
from docx import Document
from docx.shared import Inches,Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH,WD_BREAK
from hashlib import sha256
from zipfile import ZipFile

root=Path.cwd(); out=root/'outputs'
path=out/'Báo cáo sơ bộ nghỉ phép Happy Connect.docx'
doc=Document(path)
paragraphs=doc.paragraphs
heading=next(p for p in paragraphs if p.text=='II. Workflow')
image_p=next(p for p in paragraphs[paragraphs.index(heading)+1:] if p._p.xpath('.//w:drawing'))
original_table=doc.tables[0]._tbl.xml
original_state=next(p for p in paragraphs if p.text=='III. Biểu đồ trạng thái')._p.getnext()
original_state_xml=original_state.xml
def after(anchor,text='',page=False):
 p=doc.add_paragraph(text)
 anchor._p.addnext(p._p)
 if page: p.add_run().add_break(WD_BREAK.PAGE)
 return p
caption=heading.insert_paragraph_before('')
# Move the caption directly below section II.
heading._p.addnext(caption._p)
caption.add_run('1. Tạo mới và phê duyệt yêu cầu nghỉ phép').bold=True
caption.paragraph_format.keep_with_next=True
caption.paragraph_format.space_after=Pt(6)
image_p.clear(); image_p.alignment=WD_ALIGN_PARAGRAPH.CENTER
pic1=out/'Workflow tạo mới nghỉ phép swimlane.png'
shape=image_p.add_run().add_picture(str(pic1),width=Inches(6.45))
shape._inline.docPr.set('descr','Workflow tạo mới và phê duyệt nghỉ phép theo swimlane tác nhân')
image_p.paragraph_format.space_after=Pt(3)
br=after(image_p,page=True)
cap2=after(br,'2. Đề nghị sửa hoặc hủy đơn nghỉ phép đã duyệt')
cap2.runs[0].bold=True; cap2.paragraph_format.keep_with_next=True; cap2.paragraph_format.space_after=Pt(6)
p2=after(cap2); p2.alignment=WD_ALIGN_PARAGRAPH.CENTER; p2.paragraph_format.space_after=Pt(3)
pic2=out/'Workflow sửa hủy nghỉ phép swimlane.png'
shape=p2.add_run().add_picture(str(pic2),width=Inches(6.45))
shape._inline.docPr.set('descr','Workflow đề nghị sửa hoặc hủy đơn nghỉ phép đã duyệt theo swimlane tác nhân')
assert doc.tables[0]._tbl.xml==original_table
assert original_state.xml==original_state_xml
doc.save(path)
check=Document(path)
assert len(check.inline_shapes)==3
assert len(check.tables[0].columns)==7 and len(check.tables[0].rows)==13
assert check.tables[0]._tbl.xml==original_table
with ZipFile(path) as z:
 assert z.testzip() is None
 media={sha256(z.read(n)).hexdigest() for n in z.namelist() if n.startswith('word/media/')}
 assert sha256(pic1.read_bytes()).hexdigest() in media
 assert sha256(pic2.read_bytes()).hexdigest() in media
print('Verified: both current swimlane images embedded; existing state diagram and 7-column function table preserved.')
print(path)
