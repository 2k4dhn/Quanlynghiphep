Reference: C:\Users\ADMIN\OneDrive\Desktop\Nguyen_VTIT\SRS_Chuc_nang_quan_ly_mo_cua_ngoai_gio.docx
SHA256: 11bf2d7aab95ee1bc10d5f848ca56384635fa60d9af117224db596e5d5fb9283
Base geometry and Arial styles retained. Body rewritten for leave SRS; header/footer renamed; unrelated source content removed. Sample structures combined: 5 SRS chapters + open items, 2-column functional specs, 7-column UI data form. 16 editable function forms, 23 BR, 17 AC; 4 diagrams retained. Unknown values intentionally blank. Bundled renderer unavailable because soffice.exe is missing; no full-page visual QA claim.
