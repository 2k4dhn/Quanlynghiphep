from PIL import Image,ImageDraw,ImageFont
from pathlib import Path
from html import escape
import math

OUT=Path('outputs'); OUT.mkdir(exist_ok=True)
class Chart:
 def __init__(self,title,lanes,height=2220):
  self.w=2600; self.h=height; self.im=Image.new('RGB',(self.w,self.h),'white'); self.d=ImageDraw.Draw(self.im); self.svg=[]; self.labels=[]
  self.rect(2,2,2598,height-2,'white','#3f63a4',3)
  self.rect(3,3,2597,115,'#3f63a4','#3f63a4')
  self.txt(1300,58,title,44,'white',True)
  width=2594/len(lanes)
  for i,lane in enumerate(lanes):
   left=3+i*width; right=left+width
   self.rect(left,115,right,215,'#3f63a4','#3f63a4')
   self.line([(left,115),(left,height-3)],'#3f63a4',2)
   self.txt((left+right)/2,165,lane,37,'white',True)
 def rect(self,x1,y1,x2,y2,fill,stroke,width=2,r=0):
  if r: self.d.rounded_rectangle((x1,y1,x2,y2),radius=r,fill=fill,outline=stroke,width=width)
  else: self.d.rectangle((x1,y1,x2,y2),fill=fill,outline=stroke,width=width)
  self.svg.append(f'<rect x="{x1}" y="{y1}" width="{x2-x1}" height="{y2-y1}" rx="{r}" fill="{fill}" stroke="{stroke}" stroke-width="{width}"/>')
 def line(self,pts,color='#6f91d3',width=3):
  self.d.line(pts,fill=color,width=width,joint='curve'); self.svg.append('<polyline points="'+' '.join(f'{x},{y}' for x,y in pts)+f'" fill="none" stroke="{color}" stroke-width="{width}"/>')
 def txt(self,x,y,s,size=34,color='#244474',bold=False,bg=False):
  f=ImageFont.truetype('C:/Windows/Fonts/arialbd.ttf' if bold else 'C:/Windows/Fonts/arial.ttf',size)
  lines=s.split('\n'); widths=[self.d.textbbox((0,0),l,font=f)[2] for l in lines]; h=len(lines)*(size+10)
  if bg: self.rect(x-max(widths)/2-8,y-h/2-4,x+max(widths)/2+8,y+h/2+4,'white','white',0)
  for j,l in enumerate(lines):
   bb=self.d.textbbox((0,0),l,font=f); yy=y-h/2+j*(size+10)
   self.d.text((x-widths[j]/2,yy-bb[1]),l,font=f,fill=color)
   self.svg.append(f'<text x="{x}" y="{yy+size}" text-anchor="middle" font-family="Arial" font-size="{size}" font-weight="{"bold" if bold else "normal"}" fill="{color}">{escape(l)}</text>')
 def box(self,x,y,s,w=500,h=140):
  self.rect(x-w/2,y-h/2,x+w/2,y+h/2,'#518bb7','#426d9b',3,22); self.txt(x,y,s,34,'white')
 def gate(self,x,y,s,w=270,h=190):
  pts=[(x,y-h/2),(x+w/2,y),(x,y+h/2),(x-w/2,y)]
  self.d.polygon(pts,fill='#518bb7',outline='#426d9b',width=3)
  self.svg.append('<polygon points="'+' '.join(f'{a},{b}' for a,b in pts)+'" fill="#518bb7" stroke="#426d9b" stroke-width="3"/>'); self.txt(x,y,s,30,'white')
 def event(self,x,y,end=False):
  if end:
   self.d.ellipse((x-43,y-43,x+43,y+43),outline='#b8bec8',width=3); self.svg.append(f'<circle cx="{x}" cy="{y}" r="43" fill="white" stroke="#b8bec8" stroke-width="3"/>')
  self.d.ellipse((x-33,y-33,x+33,y+33),fill='#4775c6'); self.svg.append(f'<circle cx="{x}" cy="{y}" r="33" fill="#4775c6"/>')
 def arrow(self,pts,label='',at=None):
  self.line(pts); a,b=pts[-2:]; ang=math.atan2(b[1]-a[1],b[0]-a[0]); sz=17
  ps=[b,(b[0]-sz*math.cos(ang-.5),b[1]-sz*math.sin(ang-.5)),(b[0]-sz*math.cos(ang+.5),b[1]-sz*math.sin(ang+.5))]
  self.d.polygon(ps,fill='#6f91d3'); self.svg.append('<polygon points="'+' '.join(f'{x},{y}' for x,y in ps)+'" fill="#6f91d3"/>')
  if label and at: self.labels.append((*at,label))
 def save(self,name):
  for x,y,s in self.labels: self.txt(x,y,s,29,bg=True)
  self.im.save(OUT/(name+'.png'))
  (OUT/(name+'.svg')).write_text(f'<svg xmlns="http://www.w3.org/2000/svg" width="{self.w}" height="{self.h}" viewBox="0 0 {self.w} {self.h}">' + ''.join(self.svg)+'</svg>',encoding='utf8')

c=Chart('Quy trình tạo mới và phê duyệt yêu cầu nghỉ phép',['Nhân viên','Happy Connect','Người duyệt theo PL02','HR SSC'])
# Connections are drawn first to keep nodes readable.
c.arrow([(325,303),(325,340)])
c.arrow([(575,420),(725,420)])
c.arrow([(975,500),(975,525)])
c.arrow([(840,620),(575,620)],'Không đạt',(700,575))
c.arrow([(75,620),(40,620),(40,420),(75,420)])
c.arrow([(975,715),(975,760)],'Đạt',(1025,735))
c.arrow([(1225,850),(1375,850)])
c.arrow([(1625,925),(1625,1005)])
c.arrow([(1760,1100),(1930,1100),(1930,1640),(1875,1640)],'Từ chối',(1810,1155))
c.arrow([(1625,1195),(1625,1275)],'Duyệt',(1685,1235))
c.arrow([(1490,1370),(1320,1370),(1320,850),(1375,850)],'Còn cấp tiếp theo',(1400,1160))
c.arrow([(1490,1370),(1110,1370)],'Đủ cấp',(1250,1315))
c.arrow([(1110,1370),(1250,1370),(1250,1505),(2000,1505),(2000,1370),(2025,1370)],'Có: không lương có thỏa thuận',(1680,1505))
c.arrow([(840,1370),(690,1370),(690,1900),(725,1900)],'Không cần ký',(795,1490))
c.arrow([(2275,1450),(2275,1640)])
c.arrow([(2275,1710),(2275,1900),(1225,1900)],'Ký thành công',(2160,1810))
c.arrow([(1375,1640),(1225,1640)])
c.arrow([(975,1710),(975,1722)])
c.arrow([(975,1970),(975,2040)])
c.event(325,270)
c.box(325,420,'Mở Đăng ký\nChọn loại, hình thức nghỉ\nNhập thông tin và gửi',h=160)
c.box(975,420,'Tính ngày theo lịch làm việc\nPhân bổ quỹ còn hạn\nKiểm tra quỹ và trùng lịch',h=160)
c.gate(975,620,'Đủ quỹ,\nkhông trùng?')
c.box(325,620,'Nhận cảnh báo chặn gửi\nChỉnh sửa thông tin')
c.box(975,850,'Trừ quỹ áp dụng\nĐơn chuyển Chờ duyệt',h=180)
c.box(1625,850,'Người duyệt hiện tại\nXem và xử lý đơn',h=150)
c.gate(1625,1100,'Duyệt?')
c.gate(1625,1370,'Đủ các\ncấp duyệt?')
c.gate(975,1370,'Cần\ntrình ký?')
c.box(2275,1370,'Tiếp nhận và trình ký\nĐơn chưa hoàn tất',h=160)
c.box(2275,1640,'Nhận kết quả\ntrình ký thành công')
c.box(1625,1640,'Nhập lý do từ chối\nGhi người, thời gian xử lý')
c.box(975,1640,'Đơn chuyển Từ chối\nHoàn phần quỹ còn hạn')
c.event(975,1765,True)
c.box(975,1900,'Đã duyệt / hoàn tất\nGhi kết quả và lịch sử')
c.event(975,2083,True)
c.txt(1550,320,'QLTT; thêm Trưởng phòng TCLĐ\nđối với nghỉ không lương',29)
c.txt(2275,2000,'Ký thất bại / bị từ chối:\nquy tắc chưa chốt',29)
c.txt(1300,2160,'Đơn Chờ duyệt liên quan phép cũ: qua 31/03 tự hủy toàn bộ, chỉ hoàn phần phép mới còn hạn.',29)
c.save('Workflow tạo mới nghỉ phép swimlane')

c=Chart('Quy trình đề nghị sửa hoặc hủy đơn nghỉ phép đã duyệt',['Nhân viên','Happy Connect','Người duyệt theo PL02'])
xn,xs,xd=433,1300,2167
c.arrow([(xn,303),(xn,345)])
c.arrow([(xn+250,420),(xs-135,420)])
c.arrow([(xs-135,420),(xn+250,690)],'Đã khóa',(850,580))
c.arrow([(xn,760),(xn,817)])
c.arrow([(xs,515),(xs,675)],'Chưa khóa',(1360,590))
c.arrow([(xs,845),(xs,905)])
c.arrow([(xs-135,1000),(xn+250,1000)],'Không hợp lệ',(880,950))
c.arrow([(xn,1070),(xn,1137)])
c.arrow([(xs,1095),(xs,1190)],'Hợp lệ',(1355,1140))
c.arrow([(xs+250,1270),(xd-250,1270)])
c.arrow([(xd,1345),(xd,1425)])
c.arrow([(xd+135,1520),(2530,1520),(2530,1270),(xd+250,1270)],'Duyệt, còn cấp',(2410,1390))
c.arrow([(xd-135,1520),(xs+250,1660)],'Duyệt đủ cấp',(1730,1550))
c.arrow([(xd,1615),(xd,1775)],'Từ chối',(2220,1690))
c.arrow([(xd-250,1850),(xs+250,1850)])
c.arrow([(xs-250,1660),(970,1660),(970,1727)])
c.arrow([(xs,1925),(xs,1977)])
c.event(xn,270)
c.box(xn,420,'Mở đơn đã duyệt\nChọn đề nghị sửa / hủy',h=150)
c.gate(xs,420,'Chốt công /\nđến trình ký?')
c.box(xn,690,'Không cho sửa / hủy')
c.event(xn,860,True)
c.box(xs,760,'Nếu sửa: kiểm tra lịch,\nquỹ đã cấp và trùng đơn\nNếu hủy: không xét thiếu quỹ',h=170)
c.gate(xs,1000,'Hợp lệ?')
c.box(xn,1000,'Chặn cập nhật\nGiữ đơn và quỹ cũ')
c.event(xn,1180,True)
c.box(xs,1270,'Tạo đề nghị Chờ duyệt\nSửa: điều chỉnh quỹ lúc gửi\nHủy: chưa hoàn quỹ',h=160)
c.box(xd,1270,'Tiếp nhận đề nghị\nDuyệt tuần tự từng cấp',h=150)
c.gate(xd,1520,'Kết quả\nduyệt?')
c.box(xs,1660,'Sửa: áp dụng nội dung mới\nHủy: đơn gốc Đã hủy,\nhoàn phần quỹ còn hạn',h=140)
c.event(970,1770,True)
c.box(xd,1850,'Từ chối đề nghị')
c.box(xs,1850,'Giữ đơn gốc đã duyệt\nNếu sửa: khôi phục quỹ cũ\nKhông hồi sinh quỹ hết hạn',h=150)
c.event(xs,2020,True)
c.txt(1300,2120,'Qua 31/03: tự hủy đề nghị liên quan phép cũ; giữ đơn gốc, xử lý khôi phục quỹ theo nguồn còn hạn.',29)
c.txt(1300,2170,'Sửa đơn chưa duyệt: cập nhật ngay, duyệt lại từ cấp 1. Hủy đơn chưa duyệt: hủy ngay.',29)
c.save('Workflow sửa hủy nghỉ phép swimlane')
print('Created two PNG diagrams and editable SVG versions.')
