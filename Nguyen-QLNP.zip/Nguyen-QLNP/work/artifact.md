Reference: C:\Users\ADMIN\AppData\Local\Temp\codex-file-preview-rLmqQu\Nghiệp vụ quản lý yêu cầu nhập kho.docx
SHA256: 94a2210cdd3c30128d78ca5d687e429ffadf2ac1ff3801e04a577f3a740664a4
Page system: Letter portrait; margins 2.54 cm. Retain source section properties.
Typography: Times New Roman 12 pt body; source Heading1 title adapted to 18 pt black; table 11 pt.
Structure: I–IV retained; workflows and state diagrams are editable text. Function table retains source column widths and borders; repeat header; no split rows.
Slots: source title, purpose, workflow images, state image and function rows replaced. All unknown rules and priorities blank. 13 concise function rows.
Package: only word/document.xml changed; all other parts byte-for-byte retained. Original images retained in package but unused in body.
Intentional changes: explicit page break before IV for legibility; concise content.
Render evidence: renderer attempted, blocked because bundled soffice.exe unavailable. No visual QA claim.
