from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
from docx import Document

path=Path('outputs/Báo cáo sơ bộ nghỉ phép Happy Connect.docx')
doc=Document(path)
shape=list(doc.inline_shapes)[2]
rid=shape._inline.graphic.graphicData.pic.blipFill.blip.embed
partname=str(doc.part.rels[rid].target_part.partname).lstrip('/')
with ZipFile(path) as z: original={n:z.read(n) for n in z.namelist()}
script=Path('work/update_state_diagram.py').read_text(encoding='utf8')
exec(script[:script.index("path=OUT/'Báo cáo")])
image=Path('outputs/Biểu đồ trạng thái đơn nghỉ phép cập nhật.png').read_bytes()
assert image!=original[partname]
updated=dict(original); updated[partname]=image
with ZipFile(path,'w',ZIP_DEFLATED) as z:
 for name,data in updated.items(): z.writestr(name,data)
with ZipFile(path) as z:
 assert z.testzip() is None
 assert all(z.read(name)==data for name,data in original.items() if name!=partname)
assert len(Document(path).inline_shapes)==4
print('Updated only the annotated diagram image; document layout and other package parts unchanged.')
