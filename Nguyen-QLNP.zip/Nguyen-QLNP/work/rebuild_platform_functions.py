from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
from copy import deepcopy
from lxml import etree as E
from docx import Document

path=Path('outputs/Báo cáo sơ bộ nghỉ phép Happy Connect.docx')
with ZipFile(path) as z: original={n:z.read(n) for n in z.namelist()}
W='http://schemas.openxmlformats.org/wordprocessingml/2006/main'; ns={'w':W}
def tag(x): return '{'+W+'}'+x
doc=E.fromstring(original['word/document.xml']); body=doc.find('w:body',ns); table=body.find('w:tbl',ns)
sample=deepcopy(table.findall('w:tr',ns)[1])
rows=[
('Happy Connect','Đăng ký','Xem danh sách đơn của tôi','Hiển thị đơn của nhân viên tại tab Đăng ký.','Tên tab đổi từ Đơn của tôi sang Đăng ký. Hiển thị loại/hình thức nghỉ, thời gian, số ngày, trạng thái và người xử lý.'),
('Happy Connect','Đăng ký','Tạo yêu cầu nghỉ phép','Nhập thông tin, kiểm tra và gửi đơn.','Một đơn một loại nghỉ. Nghỉ không lương bắt buộc chọn Có thỏa thuận / Không thỏa thuận. Lý do nghỉ và người tiếp nhận công việc bắt buộc. Chặn nếu thiếu quỹ đã cấp hoặc trùng đơn Chờ duyệt/Đã duyệt.'),
('Happy Connect','Quỹ nghỉ','Xem quỹ và tạm tính khi đăng ký','Hiển thị quỹ khả dụng, ngày nghỉ hợp lệ và dự kiến còn lại.','Tính theo nửa ngày, theo lịch làm việc có hiệu lực; ngày làm bù tính là ngày làm việc. Phân bổ phép cũ/mới theo ngày nghỉ; không dùng quỹ tương lai. Không lương không trừ quỹ phép năm/nghỉ dưỡng.'),
('Happy Connect','Điều chỉnh','Sửa đơn / gửi đề nghị điều chỉnh','Cập nhật nội dung và lý do điều chỉnh.','Chưa duyệt hoàn tất: sửa ngay và duyệt lại từ cấp 1. Đã duyệt: đề nghị Điều chỉnh ở Chờ duyệt, điều chỉnh quỹ lúc gửi. Thiếu quỹ/trùng lịch: giữ đơn, quỹ và bước duyệt cũ. Đã chốt công/đến trình ký: khóa sửa.'),
('Happy Connect','Hủy','Hủy đơn / gửi đề nghị hủy','Nhập lý do, xác nhận thao tác hủy.','Chưa duyệt hoàn tất: hủy ngay. Đã duyệt: đề nghị Hủy ở Chờ duyệt, chưa hoàn quỹ; chấp thuận mới hủy đơn gốc. Chỉ hoàn nguồn quỹ còn hạn. Đã chốt công/đến trình ký: khóa hủy.'),
('Happy Connect','Theo dõi','Xem lịch sử xử lý','Hiển thị các lần xử lý của đơn và đề nghị.','Gồm người thực hiện, thời gian, thao tác, kết quả và lý do; giữ kết quả cấp duyệt cũ trong lịch sử khi sửa và duyệt lại từ cấp 1.'),
('Happy Connect','Phê duyệt','Xử lý đề nghị điều chỉnh / hủy','Duyệt hoặc từ chối đề nghị gắn với đơn đã duyệt.','Giữ bản đơn gốc đã duyệt. Duyệt sửa: cập nhật đơn; duyệt hủy: đơn gốc Đã hủy. Từ chối: giữ đơn gốc; nếu sửa thì khôi phục quỹ cũ nhưng không đưa phép hết hạn vào quỹ khả dụng.'),
('Happy Connect / Web HRM','Tra cứu','Tìm kiếm và lọc yêu cầu','Tra cứu theo tiêu chí của từng nền tảng.','Happy Connect: mã đơn/loại nghỉ/lý do; loại, trạng thái, người duyệt, ngày nghỉ/ngày gửi. Web HRM: nhân viên/mã yêu cầu, đơn vị, loại nghỉ, trạng thái, ngày nghỉ/gửi/xử lý và người duyệt. Tái sử dụng bộ lọc hiện có.'),
('Happy Connect / Web HRM','Theo dõi','Xem chi tiết yêu cầu','Hiển thị nội dung đơn và thông tin xử lý.','Happy Connect: thông tin đăng ký, hình thức không lương, tệp và lịch sử. Web HRM: thêm thông tin nhân sự/đơn vị, quỹ phép năm và bước xử lý; nút duyệt/từ chối theo quyền và trạng thái.'),
('Happy Connect / Web HRM','Phê duyệt','Xem danh sách cần phê duyệt','Hiển thị đơn thuộc phạm vi người duyệt.','Happy Connect có nhóm Đơn nghỉ phép, Đề nghị hủy, Đề nghị điều chỉnh. Web HRM hiển thị bảng nhân viên, đơn vị, thời gian, số ngày, trạng thái, cấp xử lý và người duyệt; có phân trang.'),
('Happy Connect / Web HRM','Phê duyệt','Duyệt / từ chối đơn nghỉ','Xem đơn và xác nhận kết quả.','Duyệt tuần tự theo loại công nghỉ và PL02; từ chối bắt buộc lý do. Happy Connect áp dụng hoàn quỹ còn hạn và nhánh trình ký đã chốt. Không lương có thỏa thuận chỉ hoàn tất sau ký thành công.'),
('Happy Connect / Web HRM','Phê duyệt','Duyệt / từ chối nhiều đơn','Chọn nhiều đơn và xác nhận xử lý.','Happy Connect có chọn từng đơn/tất cả, bỏ chọn, số đơn chọn. Web HRM chỉ chọn đơn Chờ duyệt được giao trên trang hiện tại. Không bỏ qua cấp duyệt. Xử lý khi một đơn không hợp lệ: '),
('Web HRM','Quỹ nghỉ','Xem quỹ phép năm của nhân sự','Hiển thị quỹ trên danh sách và chi tiết phục vụ duyệt.','Các chỉ tiêu trên prototype: Được cấp, Đã sử dụng, Yêu cầu nghỉ, Còn lại. Chức năng này không phải form tạo đơn hoặc tạm tính khi đăng ký. Phân tách phép cũ/mới trên Web: '),
('Web HRM','Báo cáo','Xuất danh sách yêu cầu nghỉ','Xuất dữ liệu bằng nút Xuất file hiện có.','Định dạng, bộ cột, phạm vi theo bộ lọc/quyền và cách xuất dữ liệu nhiều trang: '),
]
def fill(cell,text):
 p=deepcopy(cell.find('w:p',ns)); rp=p.find('w:r/w:rPr',ns)
 for c in list(p):
  if c.tag!=tag('pPr'): p.remove(c)
 r=E.SubElement(p,tag('r'))
 if rp is not None: r.append(deepcopy(rp))
 for i,line in enumerate(text.split('\n')):
  if i: E.SubElement(r,tag('br'))
  t=E.SubElement(r,tag('t')); t.text=line
 for c in list(cell):
  if c.tag!=tag('tcPr'): cell.remove(c)
 cell.append(p)
for tr in table.findall('w:tr',ns)[1:]: table.remove(tr)
for i,row in enumerate(rows,1):
 tr=deepcopy(sample)
 for c,txt in zip(tr.findall('w:tc',ns),[str(i),*row,'']): fill(c,txt)
 table.append(tr)

for p in body.findall('w:p',ns):
 text=''.join(p.itertext())
 if text.startswith('Cột Nền tảng phân loại'):
  replacement='Cột Nền tảng phân biệt chức năng theo prototype Happy Connect và Web HRM. Các yêu cầu thay đổi giao diện/nghiệp vụ đã chốt áp dụng cho Happy Connect; phạm vi điều chỉnh tương ứng trên Web HRM chưa chốt. Chức năng chưa thể hiện trên Web không mặc định là có.'
 elif text.startswith('Quy tắc nghiệp vụ: danh mục'):
  replacement='Quy tắc chung đã chốt cho Happy Connect: danh mục và luồng duyệt cấu hình trong DB. Phép năm cơ bản tối đa 12 ngày/năm, cấp 1 ngày đầu tháng; vào làm 15/08 thì 01/09 có 1 ngày. Thử việc tích lũy, ký HĐLĐ chính thức mới đưa quỹ còn hạn vào sử dụng. Mỗi đủ 5 năm thâm niên cộng ngay 1 ngày. Nghỉ dưỡng cấp 3 ngày từ đầu năm sau năm vào làm, hết hạn 31/12; nếu còn thử việc thì tích lũy đến khi ký chính thức.'
 elif text.startswith('Nội dung chưa chốt: ánh xạ'):
  replacement='Nội dung chưa chốt: xử lý ngày nghỉ bù lễ; cấp phép khi vào làm đúng ngày đầu tháng; ánh xạ Nghỉ việc riêng với Rv; phạm vi xử lý đề nghị sửa/hủy trên Web HRM; tích hợp và xử lý trình ký thất bại/bị từ chối:'
 else: continue
 for c in list(p):
  if c.tag!=tag('pPr'): p.remove(c)
 r=E.SubElement(p,tag('r')); t=E.SubElement(r,tag('t')); t.text=replacement
note=E.Element(tag('p')); r=E.SubElement(note,tag('r')); t=E.SubElement(r,tag('t'))
t.text='Quy tắc hết hạn và phân bổ: phép dư năm trước dùng đến hết 31/03, ưu tiên cho ngày nghỉ còn trong hạn; từ 01/04 dùng phép mới. Mỗi đơn một loại nghỉ nhưng có thể dùng nhiều nguồn phép năm. Đơn qua năm phải đủ quỹ đã cấp của từng năm. Đơn/đề nghị Chờ duyệt liên quan phép cũ tự hủy toàn bộ qua 31/03, lý do Phép cũ hết hạn; hủy đề nghị giữ đơn gốc. Hoàn/khôi phục quỹ theo từng nguồn, không làm phép hết hạn khả dụng trở lại. Sửa/hủy được sau kỳ nghỉ nhưng trước chốt công; đến trình ký thì khóa thao tác.'
body.insert(list(body).index(table)+1,note)
parts=dict(original); parts['word/document.xml']=E.tostring(doc,xml_declaration=True,encoding='UTF-8',standalone=True)
with ZipFile(path,'w',ZIP_DEFLATED) as z:
 for n,b in parts.items(): z.writestr(n,b)
d=Document(path)
assert len(d.tables[0].rows)==15 and len(d.tables[0].columns)==7
assert len(d.inline_shapes)==4
assert all(not r.cells[6].text for r in d.tables[0].rows[1:])
assert any(r.cells[1].text=='Web HRM' and 'Xuất' in r.cells[3].text for r in d.tables[0].rows)
with ZipFile(path) as z:
 assert z.testzip() is None
 assert all(z.read(n)==b for n,b in original.items() if n!='word/document.xml')
print('Verified 14 business functions, explicit platform split, current confirmed rules; all four diagrams preserved.')
