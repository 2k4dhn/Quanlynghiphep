from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from lxml import etree as E
from docx import Document

path=Path('outputs/Báo cáo sơ bộ nghỉ phép Happy Connect.docx')
with ZipFile(path) as z: parts={n:z.read(n) for n in z.namelist()}
W='http://schemas.openxmlformats.org/wordprocessingml/2006/main'; ns={'w':W}
tag=lambda x:'{'+W+'}'+x
doc=E.fromstring(parts['word/document.xml']); body=doc.find('w:body',ns)
table=body.find('w:tbl',ns)
cell=table.findall('w:tr',ns)[1].findall('w:tc',ns)[5]
needle='Tên tab đổi từ Đơn của tôi sang Đăng ký. '
changed=False
for t in cell.findall('.//w:t',ns):
 if needle in (t.text or ''):
  t.text=t.text.replace(needle,''); changed=True
assert changed
scope=next(p for p in body.findall('w:p',ns) if ''.join(p.itertext()).startswith('Giới hạn thay đổi:'))
note=E.Element(tag('p')); r=E.SubElement(note,tag('r')); t=E.SubElement(r,tag('t'))
t.text='Yêu cầu giao diện trên Happy Connect: đổi tên tab Đơn của tôi thành Đăng ký; giữ nguyên vị trí, kiểu hiển thị và chức năng của tab.'
body.insert(list(body).index(scope)+1,note)
updated=dict(parts); updated['word/document.xml']=E.tostring(doc,xml_declaration=True,encoding='UTF-8',standalone=True)
with ZipFile(path,'w',ZIP_DEFLATED) as z:
 for n,b in updated.items(): z.writestr(n,b)
d=Document(path)
assert needle.strip() not in d.tables[0].cell(1,5).text
assert 'Danh sách' not in d.tables[0].cell(1,5).text or d.tables[0].cell(1,5).text
assert len(d.tables[0].rows)==15 and len(d.inline_shapes)==4
with ZipFile(path) as z:
 assert z.testzip() is None
 assert all(z.read(n)==b for n,b in parts.items() if n!='word/document.xml')
print('Moved tab-renaming requirement from business table to separate UI note; diagrams preserved.')
